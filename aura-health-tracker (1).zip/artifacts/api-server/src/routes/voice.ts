import { Router, type IRouter } from "express";
import OpenAI, { toFile } from "openai";
import { requireAuth } from "./auth";

const router: IRouter = Router();

function getOpenAI() {
  return new OpenAI({
    apiKey: process.env.AI_INTEGRATIONS_OPENAI_API_KEY,
    baseURL: process.env.AI_INTEGRATIONS_OPENAI_BASE_URL,
  });
}

router.post("/voice/process-audio", requireAuth, async (req: any, res): Promise<void> => {
  const { audioBase64, mimeType } = req.body as { audioBase64?: string; mimeType?: string };

  if (!audioBase64) {
    res.status(400).json({ error: "audioBase64 required" });
    return;
  }

  const client = getOpenAI();
  const audioBuffer = Buffer.from(audioBase64, "base64");

  // Step 1: Speech-to-text
  let transcript = "";
  try {
    const ext = mimeType?.includes("mp4") ? "mp4"
      : mimeType?.includes("wav") ? "wav"
      : mimeType?.includes("ogg") ? "ogg"
      : "webm";
    const file = await toFile(audioBuffer, `audio.${ext}`, { type: mimeType || "audio/webm" });
    const transcription = await client.audio.transcriptions.create({
      file,
      model: "gpt-4o-mini-transcribe",
    } as any);
    transcript = (transcription as any).text ?? "";
  } catch (err: any) {
    req.log.error({ err: err?.message }, "STT transcription failed");
    res.status(500).json({ error: "Could not transcribe audio", detail: err?.message });
    return;
  }

  if (!transcript.trim()) {
    res.json({
      transcript: "",
      response: "I didn't catch that — could you speak a little louder?",
      intent: "unknown",
      meal: null,
      audioBase64: null,
    });
    return;
  }

  req.log.info({ transcript }, "Voice transcript received");

  // Step 2: Understand intent + generate reply via GPT
  let parsed: { intent: string; response: string; meal: any } = {
    intent: "unknown",
    response: "I didn't understand that. Try saying 'I ate rice' or 'Show my summary'.",
    meal: null,
  };

  try {
    const completion = await client.chat.completions.create({
      model: "gpt-5",
      max_completion_tokens: 512,
      messages: [
        {
          role: "system",
          content: `You are AURA, a warm and encouraging AI health assistant built into a nutrition tracking app. Parse the user's voice command and respond naturally.

Return ONLY a valid JSON object with this exact structure — no markdown, no extra text:
{
  "intent": "add_food" | "show_summary" | "show_dashboard" | "get_advice" | "unknown",
  "response": "Your spoken reply — friendly, concise, 1-2 sentences",
  "meal": null | {
    "name": "Food name",
    "calories": 123,
    "protein": 10,
    "fat": 5,
    "carbs": 20,
    "category": "protein" | "carbs" | "fats" | "vegetables" | "fruits" | "dairy" | "other",
    "period": "morning" | "afternoon" | "evening" | "night" | null
  }
}

Rules:
- If user mentions eating/drinking/having food → intent "add_food", populate meal with realistic estimated nutrition
- If user says they're tired, need energy, asks for advice → intent "get_advice", provide helpful tip
- Estimate calories and macros based on typical serving sizes
- If meal period is not mentioned, infer from context or leave null
- Be encouraging and warm in your responses
- If you can't understand the command, explain what AURA can do`,
        },
        { role: "user", content: transcript },
      ],
    });

    const text = completion.choices[0]?.message?.content ?? "";
    const match = text.match(/\{[\s\S]*\}/);
    if (match) parsed = JSON.parse(match[0]);
  } catch (err: any) {
    req.log.error({ err: err?.message }, "GPT voice understanding failed");
  }

  // Step 3: Text-to-speech using gpt-audio
  let audioBase64Response: string | null = null;
  try {
    const ttsCompletion = await client.chat.completions.create({
      model: "gpt-audio",
      modalities: ["text", "audio"],
      audio: { voice: "nova", format: "mp3" },
      messages: [
        {
          role: "system",
          content: "You are a text-to-speech system. Repeat the following text exactly, word for word, with a warm and encouraging tone.",
        },
        { role: "user", content: `Repeat exactly: ${parsed.response}` },
      ],
    } as any);
    const audioData = (ttsCompletion.choices[0]?.message as any)?.audio?.data;
    if (audioData) audioBase64Response = audioData;
  } catch (err: any) {
    req.log.warn({ err: err?.message }, "TTS failed, returning text only");
  }

  res.json({
    transcript,
    response: parsed.response,
    intent: parsed.intent,
    meal: parsed.meal ?? null,
    audioBase64: audioBase64Response,
  });
});

export default router;
