import { Router, type IRouter } from "express";
import { eq, and, gte } from "drizzle-orm";
import { db, usersTable, mealsTable } from "@workspace/db";
import { requireAuth } from "./auth";

const router: IRouter = Router();

router.get("/recommendations", requireAuth, async (req: any, res): Promise<void> => {
  const [user] = await db.select().from(usersTable).where(eq(usersTable.id, req.userId));
  const today = new Date().toISOString().split("T")[0];

  const todayMeals = await db.select().from(mealsTable).where(
    and(eq(mealsTable.userId, req.userId), eq(mealsTable.date, today))
  );

  const totalCals = todayMeals.reduce((s, m) => s + m.calories, 0);
  const totalProtein = todayMeals.reduce((s, m) => s + m.protein, 0);
  const totalFat = todayMeals.reduce((s, m) => s + m.fat, 0);

  const target = user?.calorieTarget ?? 2000;
  const proteinTarget = user?.proteinTarget ?? 120;
  const hour = new Date().getHours();

  const recs: any[] = [];
  let id = 1;

  // Calorie-based
  if (totalCals < target * 0.4 && hour > 12) {
    recs.push({
      id: id++,
      type: "nutrition",
      title: "You're under your calorie goal",
      description: "Consider a balanced meal with complex carbs and lean protein to stay energized.",
      priority: "high",
      icon: "flame",
    });
  }

  if (totalProtein < proteinTarget * 0.5 && hour > 14) {
    recs.push({
      id: id++,
      type: "nutrition",
      title: "Boost your protein intake",
      description: "Try adding chicken, eggs, greek yogurt, or legumes to your next meal.",
      priority: "high",
      icon: "dumbbell",
    });
  }

  // Time-based activity recommendations
  if (hour >= 6 && hour < 10) {
    recs.push({
      id: id++,
      type: "activity",
      title: "Morning yoga session",
      description: "A 20-minute morning yoga routine boosts metabolism and sets a positive tone for the day.",
      priority: "medium",
      icon: "activity",
    });
  }

  if (hour >= 17 && hour < 20) {
    recs.push({
      id: id++,
      type: "activity",
      title: "Evening walk recommended",
      description: "A 30-minute brisk walk after dinner aids digestion and burns an additional 150 calories.",
      priority: "medium",
      icon: "footprints",
    });
  }

  // Hydration
  recs.push({
    id: id++,
    type: "hydration",
    title: "Stay hydrated",
    description: "Aim for 8 glasses of water today. Proper hydration improves nutrient absorption by up to 30%.",
    priority: "medium",
    icon: "droplets",
  });

  // Goal-specific
  if (user?.goal === "lose_weight") {
    recs.push({
      id: id++,
      type: "nutrition",
      title: "Choose light evening meals",
      description: "For weight loss, keep evening meals under 500 calories with high fiber content.",
      priority: "medium",
      icon: "leaf",
    });
  }

  if (user?.goal === "gain_muscle") {
    recs.push({
      id: id++,
      type: "nutrition",
      title: "Post-workout protein window",
      description: "Consume 25-40g of protein within 30 minutes post-workout for optimal muscle synthesis.",
      priority: "high",
      icon: "dumbbell",
    });
  }

  // Rest
  if (hour >= 21) {
    recs.push({
      id: id++,
      type: "rest",
      title: "Wind down for sleep",
      description: "Quality sleep is essential for recovery. Avoid heavy meals within 2 hours of bedtime.",
      priority: "low",
      icon: "moon",
    });
  }

  recs.push({
    id: id++,
    type: "goal",
    title: "Log all meals consistently",
    description: "Users who log every meal are 3x more likely to reach their nutrition goals on time.",
    priority: "low",
    icon: "target",
  });

  res.json(recs.slice(0, 5));
});

export default router;
