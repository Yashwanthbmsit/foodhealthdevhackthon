import { Router, type IRouter } from "express";
import { eq, and, sql } from "drizzle-orm";
import { db, mealsTable, usersTable } from "@workspace/db";
import { requireAuth } from "./auth";
import {
  CreateMealBody,
  GetMealsQueryParams,
  GetMealParams,
  DeleteMealParams,
  GetDailySummaryQueryParams,
  ProcessVoiceCommandBody,
  AnalyzeFoodBody,
} from "@workspace/api-zod";

const router: IRouter = Router();

router.get("/meals", requireAuth, async (req: any, res): Promise<void> => {
  const params = GetMealsQueryParams.safeParse(req.query);
  const date = params.success && params.data.date ? params.data.date : new Date().toISOString().split("T")[0];
  const period = params.success ? params.data.period : undefined;

  const conditions = [
    eq(mealsTable.userId, req.userId),
    eq(mealsTable.date, date),
  ];
  if (period) conditions.push(eq(mealsTable.period, period));

  const meals = await db.select().from(mealsTable).where(and(...conditions)).orderBy(mealsTable.createdAt);
  res.json(meals.map(formatMeal));
});

router.post("/meals", requireAuth, async (req: any, res): Promise<void> => {
  const parsed = CreateMealBody.safeParse(req.body);
  if (!parsed.success) { res.status(400).json({ error: parsed.error.message }); return; }

  const date = parsed.data.date ?? new Date().toISOString().split("T")[0];
  const [meal] = await db.insert(mealsTable).values({
    userId: req.userId,
    ...parsed.data,
    date,
  }).returning();

  res.status(201).json(formatMeal(meal));
});

router.get("/meals/summary", requireAuth, async (req: any, res): Promise<void> => {
  const params = GetDailySummaryQueryParams.safeParse(req.query);
  const date = params.success && params.data.date ? params.data.date : new Date().toISOString().split("T")[0];

  const meals = await db.select().from(mealsTable).where(
    and(eq(mealsTable.userId, req.userId), eq(mealsTable.date, date))
  );

  const periods = ["morning", "afternoon", "evening", "night"] as const;
  const byPeriod: Record<string, any> = {};

  for (const p of periods) {
    const pm = meals.filter(m => m.period === p);
    byPeriod[p] = {
      calories: pm.reduce((s, m) => s + m.calories, 0),
      protein: pm.reduce((s, m) => s + m.protein, 0),
      fat: pm.reduce((s, m) => s + m.fat, 0),
      carbs: pm.reduce((s, m) => s + (m.carbs ?? 0), 0),
      mealCount: pm.length,
    };
  }

  res.json({
    date,
    totalCalories: meals.reduce((s, m) => s + m.calories, 0),
    totalProtein: meals.reduce((s, m) => s + m.protein, 0),
    totalFat: meals.reduce((s, m) => s + m.fat, 0),
    totalCarbs: meals.reduce((s, m) => s + (m.carbs ?? 0), 0),
    byPeriod,
  });
});

router.get("/meals/:id", requireAuth, async (req: any, res): Promise<void> => {
  const raw = Array.isArray(req.params.id) ? req.params.id[0] : req.params.id;
  const id = parseInt(raw, 10);
  if (isNaN(id)) { res.status(400).json({ error: "Invalid id" }); return; }

  const [meal] = await db.select().from(mealsTable).where(
    and(eq(mealsTable.id, id), eq(mealsTable.userId, req.userId))
  );
  if (!meal) { res.status(404).json({ error: "Meal not found" }); return; }
  res.json(formatMeal(meal));
});

router.delete("/meals/:id", requireAuth, async (req: any, res): Promise<void> => {
  const raw = Array.isArray(req.params.id) ? req.params.id[0] : req.params.id;
  const id = parseInt(raw, 10);
  if (isNaN(id)) { res.status(400).json({ error: "Invalid id" }); return; }

  const [meal] = await db.delete(mealsTable).where(
    and(eq(mealsTable.id, id), eq(mealsTable.userId, req.userId))
  ).returning();

  if (!meal) { res.status(404).json({ error: "Meal not found" }); return; }
  res.json({ success: true });
});

// AI Food Analysis
router.post("/food-analysis/analyze", requireAuth, async (req: any, res): Promise<void> => {
  const parsed = AnalyzeFoodBody.safeParse(req.body);
  if (!parsed.success) { res.status(400).json({ error: parsed.error.message }); return; }

  const { description } = parsed.data;
  const result = estimateNutrition(description);
  res.json(result);
});

// Voice command
router.post("/voice/command", requireAuth, async (req: any, res): Promise<void> => {
  const parsed = ProcessVoiceCommandBody.safeParse(req.body);
  if (!parsed.success) { res.status(400).json({ error: parsed.error.message }); return; }

  const cmd = parsed.data.command.toLowerCase();

  if (cmd.includes("show dashboard") || cmd.includes("go to dashboard")) {
    res.json({ intent: "show_dashboard", message: "Opening your dashboard", success: true });
    return;
  }

  if (cmd.includes("show summary") || cmd.includes("show stats") || cmd.includes("how am i doing")) {
    res.json({ intent: "show_summary", message: "Here's your daily summary", success: true });
    return;
  }

  // Try to parse food intent
  const foodPhrases = ["i ate", "i had", "add", "log", "i drank", "i consumed"];
  const hasFoodIntent = foodPhrases.some(p => cmd.includes(p));

  if (hasFoodIntent) {
    let foodDesc = cmd;
    for (const phrase of foodPhrases) {
      foodDesc = foodDesc.replace(phrase, "").trim();
    }
    if (!foodDesc) foodDesc = cmd;
    const meal = estimateNutrition(foodDesc);
    res.json({
      intent: "add_food",
      message: `Found: ${meal.name}. Which period would you like to add it to?`,
      success: true,
      meal,
    });
    return;
  }

  res.json({ intent: "unknown", message: "I didn't understand that command. Try saying 'I ate rice' or 'Show dashboard'.", success: false });
});

function formatMeal(m: any) {
  return {
    id: m.id,
    userId: m.userId,
    name: m.name,
    calories: m.calories,
    protein: m.protein,
    fat: m.fat,
    carbs: m.carbs ?? null,
    period: m.period,
    date: m.date,
    category: m.category ?? null,
    imageUrl: m.imageUrl ?? null,
    createdAt: m.createdAt instanceof Date ? m.createdAt.toISOString() : String(m.createdAt),
  };
}

// Simple nutrition estimation from text
function estimateNutrition(description: string) {
  const lower = description.toLowerCase();
  const db: Record<string, any> = {
    dosa: { name: "Dosa", calories: 160, protein: 3, fat: 4, carbs: 28, category: "South Indian", confidence: 0.92 },
    idli: { name: "Idli", calories: 39, protein: 2, fat: 0.5, carbs: 8, category: "South Indian", confidence: 0.94 },
    rice: { name: "Rice (1 cup)", calories: 200, protein: 4, fat: 0.5, carbs: 45, category: "Grain", confidence: 0.95 },
    chicken: { name: "Chicken Breast (200g)", calories: 330, protein: 62, fat: 7, carbs: 0, category: "Protein", confidence: 0.93 },
    oatmeal: { name: "Oatmeal (1 cup)", calories: 154, protein: 6, fat: 3, carbs: 27, category: "Grain", confidence: 0.96 },
    oats: { name: "Oatmeal (1 cup)", calories: 154, protein: 6, fat: 3, carbs: 27, category: "Grain", confidence: 0.95 },
    banana: { name: "Banana (1 medium)", calories: 89, protein: 1, fat: 0.3, carbs: 23, category: "Fruit", confidence: 0.97 },
    apple: { name: "Apple (1 medium)", calories: 95, protein: 0.5, fat: 0.3, carbs: 25, category: "Fruit", confidence: 0.97 },
    egg: { name: "Boiled Eggs (2)", calories: 155, protein: 13, fat: 11, carbs: 1, category: "Protein", confidence: 0.95 },
    eggs: { name: "Boiled Eggs (2)", calories: 155, protein: 13, fat: 11, carbs: 1, category: "Protein", confidence: 0.95 },
    avocado: { name: "Avocado Toast", calories: 320, protein: 8, fat: 18, carbs: 35, category: "Mixed", confidence: 0.88 },
    toast: { name: "Toast (2 slices)", calories: 160, protein: 5, fat: 2, carbs: 30, category: "Grain", confidence: 0.93 },
    salad: { name: "Mixed Salad", calories: 120, protein: 4, fat: 5, carbs: 12, category: "Vegetable", confidence: 0.85 },
    protein: { name: "Protein Shake", calories: 150, protein: 30, fat: 3, carbs: 8, category: "Supplement", confidence: 0.91 },
    shake: { name: "Protein Shake", calories: 150, protein: 30, fat: 3, carbs: 8, category: "Supplement", confidence: 0.87 },
    coffee: { name: "Coffee with Milk", calories: 50, protein: 2, fat: 2, carbs: 5, category: "Beverage", confidence: 0.90 },
    dal: { name: "Dal (1 cup)", calories: 180, protein: 12, fat: 3, carbs: 30, category: "Legume", confidence: 0.91 },
    roti: { name: "Roti (2 pieces)", calories: 260, protein: 6, fat: 4, carbs: 52, category: "Grain", confidence: 0.92 },
    chapati: { name: "Chapati (2 pieces)", calories: 260, protein: 6, fat: 4, carbs: 52, category: "Grain", confidence: 0.92 },
    pasta: { name: "Pasta (200g)", calories: 280, protein: 10, fat: 4, carbs: 56, category: "Grain", confidence: 0.89 },
    pizza: { name: "Pizza (2 slices)", calories: 570, protein: 22, fat: 20, carbs: 70, category: "Mixed", confidence: 0.88 },
    burger: { name: "Beef Burger", calories: 450, protein: 25, fat: 22, carbs: 40, category: "Fast Food", confidence: 0.87 },
    sambar: { name: "Sambar (1 cup)", calories: 95, protein: 5, fat: 2, carbs: 16, category: "South Indian", confidence: 0.90 },
  };

  for (const [key, val] of Object.entries(db)) {
    if (lower.includes(key)) {
      const multiplier = extractMultiplier(lower);
      const insights = generateInsights(val, multiplier);
      return {
        name: multiplier > 1 ? `${val.name} (x${multiplier})` : val.name,
        calories: Math.round(val.calories * multiplier),
        protein: Math.round(val.protein * multiplier * 10) / 10,
        fat: Math.round(val.fat * multiplier * 10) / 10,
        carbs: Math.round(val.carbs * multiplier * 10) / 10,
        category: val.category,
        confidence: val.confidence,
        servingSize: "1 serving",
        insights,
      };
    }
  }

  // Generic fallback
  return {
    name: capitalizeFirst(description.trim()),
    calories: 250,
    protein: 10,
    fat: 8,
    carbs: 35,
    category: "Mixed",
    confidence: 0.62,
    servingSize: "1 serving",
    insights: [
      "Nutrition estimated based on similar food items",
      "For more accuracy, try describing the specific ingredients",
    ],
  };
}

function extractMultiplier(text: string): number {
  const match = text.match(/\b(\d+)\s*(piece|pieces|cup|cups|slice|slices|bowl|bowls|plate|plates)\b/);
  if (match) {
    const n = parseInt(match[1]);
    return Math.min(n, 5);
  }
  return 1;
}

function generateInsights(food: any, multiplier: number): string[] {
  const insights = [];
  if (food.protein > 20) insights.push("High protein content — great for muscle recovery");
  if (food.carbs > 40) insights.push("Rich in carbohydrates — ideal for energy before workouts");
  if (food.fat < 5) insights.push("Low in fat — supports weight management goals");
  if (food.calories < 200) insights.push("Low calorie option — good for calorie-controlled diets");
  if (multiplier > 1) insights.push(`Nutrition calculated for ${multiplier} servings`);
  if (insights.length === 0) insights.push("Balanced macronutrient profile for a regular meal");
  return insights.slice(0, 3);
}

function capitalizeFirst(str: string): string {
  return str.charAt(0).toUpperCase() + str.slice(1);
}

export default router;
