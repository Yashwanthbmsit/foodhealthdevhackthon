import { Router, type IRouter } from "express";
import healthRouter from "./health";
import authRouter from "./auth";
import usersRouter from "./users";
import mealsRouter from "./meals";
import goalsRouter from "./goals";
import analyticsRouter from "./analytics";
import recommendationsRouter from "./recommendations";
import notificationsRouter from "./notifications";
import imageAnalysisRouter from "./image-analysis";
import voiceRouter from "./voice";

const router: IRouter = Router();

router.use(healthRouter);
router.use(authRouter);
router.use(usersRouter);
router.use(mealsRouter);
router.use(goalsRouter);
router.use(analyticsRouter);
router.use(recommendationsRouter);
router.use(notificationsRouter);
router.use(imageAnalysisRouter);
router.use(voiceRouter);

export default router;
