import { Router, type IRouter } from "express";
import { eq, and, gte } from "drizzle-orm";
import { db, usersTable, mealsTable } from "@workspace/db";
import { requireAuth } from "./auth";
import { UpdateGoalsBody } from "@workspace/api-zod";

const router: IRouter = Router();

router.get("/goals", requireAuth, async (req: any, res): Promise<void> => {
  const [user] = await db.select().from(usersTable).where(eq(usersTable.id, req.userId));
  if (!user) { res.status(404).json({ error: "User not found" }); return; }

  const today = new Date().toISOString().split("T")[0];
  const meals = await db.select().from(mealsTable).where(
    and(eq(mealsTable.userId, req.userId), eq(mealsTable.date, today))
  );

  const consumed = {
    calories: meals.reduce((s, m) => s + m.calories, 0),
    protein: meals.reduce((s, m) => s + m.protein, 0),
    fat: meals.reduce((s, m) => s + m.fat, 0),
  };

  const calorieTarget = user.calorieTarget ?? 2000;
  const proteinTarget = user.proteinTarget ?? 120;
  const fatTarget = user.fatTarget ?? 65;

  const remaining = {
    calories: Math.max(0, calorieTarget - consumed.calories),
    protein: Math.max(0, proteinTarget - consumed.protein),
    fat: Math.max(0, fatTarget - consumed.fat),
  };

  const percentComplete = {
    calories: calorieTarget > 0 ? Math.min(100, (consumed.calories / calorieTarget) * 100) : 0,
    protein: proteinTarget > 0 ? Math.min(100, (consumed.protein / proteinTarget) * 100) : 0,
    fat: fatTarget > 0 ? Math.min(100, (consumed.fat / fatTarget) * 100) : 0,
  };

  let daysUntilDeadline: number | null = null;
  if (user.goalDeadline) {
    const deadline = new Date(user.goalDeadline);
    const now = new Date();
    daysUntilDeadline = Math.max(0, Math.ceil((deadline.getTime() - now.getTime()) / (1000 * 60 * 60 * 24)));
  }

  res.json({
    calorieTarget,
    proteinTarget,
    fatTarget,
    goalDeadline: user.goalDeadline ?? null,
    consumed,
    remaining,
    percentComplete,
    daysUntilDeadline,
  });
});

router.put("/goals", requireAuth, async (req: any, res): Promise<void> => {
  const parsed = UpdateGoalsBody.safeParse(req.body);
  if (!parsed.success) { res.status(400).json({ error: parsed.error.message }); return; }

  const { calorieTarget, proteinTarget, fatTarget, goalDeadline } = parsed.data;

  await db.update(usersTable).set({
    calorieTarget,
    proteinTarget,
    fatTarget,
    ...(goalDeadline ? { goalDeadline } : {}),
  }).where(eq(usersTable.id, req.userId));

  // Re-fetch updated goals
  const today = new Date().toISOString().split("T")[0];
  const meals = await db.select().from(mealsTable).where(
    and(eq(mealsTable.userId, req.userId), eq(mealsTable.date, today))
  );

  const consumed = {
    calories: meals.reduce((s, m) => s + m.calories, 0),
    protein: meals.reduce((s, m) => s + m.protein, 0),
    fat: meals.reduce((s, m) => s + m.fat, 0),
  };

  res.json({
    calorieTarget,
    proteinTarget,
    fatTarget,
    consumed,
    remaining: {
      calories: Math.max(0, calorieTarget - consumed.calories),
      protein: Math.max(0, proteinTarget - consumed.protein),
      fat: Math.max(0, fatTarget - consumed.fat),
    },
    percentComplete: {
      calories: Math.min(100, (consumed.calories / calorieTarget) * 100),
      protein: Math.min(100, (consumed.protein / proteinTarget) * 100),
      fat: Math.min(100, (consumed.fat / fatTarget) * 100),
    },
    daysUntilDeadline: null,
  });
});

export default router;
