import { Router, type IRouter } from "express";
import { eq, and, gte, lte } from "drizzle-orm";
import { db, usersTable, mealsTable } from "@workspace/db";
import { requireAuth } from "./auth";
import { GetWeeklyAnalyticsQueryParams } from "@workspace/api-zod";

const router: IRouter = Router();

router.get("/analytics/weekly", requireAuth, async (req: any, res): Promise<void> => {
  const params = GetWeeklyAnalyticsQueryParams.safeParse(req.query);
  const today = new Date();
  const dayOfWeek = today.getDay();
  const weekStart = new Date(today);
  weekStart.setDate(today.getDate() - dayOfWeek);
  weekStart.setHours(0, 0, 0, 0);

  const weekEnd = new Date(weekStart);
  weekEnd.setDate(weekStart.getDate() + 6);

  const startStr = weekStart.toISOString().split("T")[0];
  const endStr = weekEnd.toISOString().split("T")[0];

  const meals = await db.select().from(mealsTable).where(
    and(
      eq(mealsTable.userId, req.userId),
      gte(mealsTable.date, startStr),
      lte(mealsTable.date, endStr)
    )
  );

  // Build daily data
  const dailyMap = new Map<string, { calories: number; protein: number; fat: number; carbs: number }>();
  for (let i = 0; i < 7; i++) {
    const d = new Date(weekStart);
    d.setDate(weekStart.getDate() + i);
    const dateStr = d.toISOString().split("T")[0];
    dailyMap.set(dateStr, { calories: 0, protein: 0, fat: 0, carbs: 0 });
  }

  for (const meal of meals) {
    const entry = dailyMap.get(meal.date);
    if (entry) {
      entry.calories += meal.calories;
      entry.protein += meal.protein;
      entry.fat += meal.fat;
      entry.carbs += (meal.carbs ?? 0);
    }
  }

  const dailyData = Array.from(dailyMap.entries()).map(([date, data]) => ({ date, ...data }));
  const activeDays = dailyData.filter(d => d.calories > 0);

  const avgCalories = activeDays.length > 0 ? activeDays.reduce((s, d) => s + d.calories, 0) / activeDays.length : 0;
  const avgProtein = activeDays.length > 0 ? activeDays.reduce((s, d) => s + d.protein, 0) / activeDays.length : 0;
  const avgFat = activeDays.length > 0 ? activeDays.reduce((s, d) => s + d.fat, 0) / activeDays.length : 0;

  // Streak — consecutive days with logged meals up to today
  let streak = 0;
  for (let i = dayOfWeek; i >= 0; i--) {
    const d = new Date(today);
    d.setDate(today.getDate() - (dayOfWeek - i));
    const dateStr = d.toISOString().split("T")[0];
    if ((dailyMap.get(dateStr)?.calories ?? 0) > 0) streak++;
    else break;
  }

  const insights: string[] = [];
  if (avgCalories > 0) {
    if (avgCalories < 1400) insights.push("Your average calorie intake is below recommended levels. Consider adding nutrient-dense foods.");
    else if (avgCalories > 2800) insights.push("Calorie intake is above average. Focus on portion control.");
    else insights.push("Your calorie intake is within a healthy range this week.");
  }
  if (avgProtein < 80) insights.push("Protein intake could be higher — aim for more lean meats, legumes, or dairy.");
  if (streak >= 5) insights.push(`Impressive! ${streak}-day logging streak. Consistency is the key to results.`);
  if (activeDays.length < 4) insights.push("Try logging all meals daily to get more accurate insights.");

  res.json({
    weekStart: startStr,
    weekEnd: endStr,
    dailyData,
    averages: { calories: avgCalories, protein: avgProtein, fat: avgFat },
    streak,
    bestDay: activeDays.length > 0 ? activeDays.reduce((a, b) => a.protein > b.protein ? a : b).date : null,
    insights,
  });
});

router.get("/analytics/health-risks", requireAuth, async (req: any, res): Promise<void> => {
  const [user] = await db.select().from(usersTable).where(eq(usersTable.id, req.userId));
  const today = new Date().toISOString().split("T")[0];

  const last7 = new Date();
  last7.setDate(last7.getDate() - 7);

  const meals = await db.select().from(mealsTable).where(
    and(
      eq(mealsTable.userId, req.userId),
      gte(mealsTable.date, last7.toISOString().split("T")[0]),
      lte(mealsTable.date, today)
    )
  );

  const activeDays = new Set(meals.map(m => m.date)).size;
  const avgCalories = meals.length > 0 ? meals.reduce((s, m) => s + m.calories, 0) / Math.max(activeDays, 1) : 0;
  const avgProtein = meals.length > 0 ? meals.reduce((s, m) => s + m.protein, 0) / Math.max(activeDays, 1) : 0;
  const avgFat = meals.length > 0 ? meals.reduce((s, m) => s + m.fat, 0) / Math.max(activeDays, 1) : 0;
  const avgCarbs = meals.length > 0 ? meals.reduce((s, m) => s + (m.carbs ?? 0), 0) / Math.max(activeDays, 1) : 0;

  // Simple risk scoring based on dietary patterns
  const target = user?.calorieTarget ?? 2000;

  const obesityScore = Math.min(100, Math.max(0,
    (avgCalories > target * 1.3 ? 40 : avgCalories > target * 1.1 ? 20 : 10) +
    (avgFat > 80 ? 30 : avgFat > 60 ? 15 : 5) +
    (activeDays < 3 ? 20 : 10)
  ));

  const weaknessScore = Math.min(100, Math.max(0,
    (avgCalories < target * 0.7 ? 50 : avgCalories < target * 0.85 ? 25 : 10) +
    (avgProtein < 60 ? 35 : avgProtein < 90 ? 15 : 5) +
    (activeDays < 2 ? 20 : 5)
  ));

  const diabetesScore = Math.min(100, Math.max(0,
    (avgCarbs > 350 ? 40 : avgCarbs > 280 ? 20 : 10) +
    (avgCalories > target * 1.5 ? 30 : avgCalories > target * 1.2 ? 15 : 5) +
    (activeDays < 3 ? 20 : 5)
  ));

  const riskLevel = (score: number) => score < 30 ? "low" : score < 60 ? "moderate" : "high";

  res.json({
    obesityRisk: {
      level: riskLevel(obesityScore),
      score: obesityScore,
      description: obesityScore < 30
        ? "Your caloric intake and fat consumption are within healthy ranges."
        : obesityScore < 60
        ? "Moderate risk detected. Consider reducing high-fat and calorie-dense foods."
        : "High risk detected. Significantly reduce caloric surplus and saturated fats.",
    },
    weaknessRisk: {
      level: riskLevel(weaknessScore),
      score: weaknessScore,
      description: weaknessScore < 30
        ? "Adequate caloric intake and protein levels support energy and strength."
        : weaknessScore < 60
        ? "Your protein or calorie intake may be too low. Consider adding lean proteins."
        : "Low protein and insufficient calories may cause fatigue and muscle loss.",
    },
    diabetesRisk: {
      level: riskLevel(diabetesScore),
      score: diabetesScore,
      description: diabetesScore < 30
        ? "Carbohydrate intake appears balanced and healthy."
        : diabetesScore < 60
        ? "Moderate carbohydrate levels. Monitor sugary and refined foods."
        : "High carbohydrate intake detected. Reduce refined sugars and processed foods.",
    },
    overallScore: Math.round((obesityScore + weaknessScore + diabetesScore) / 3),
  });
});

router.get("/analytics/forecast", requireAuth, async (req: any, res): Promise<void> => {
  const [user] = await db.select().from(usersTable).where(eq(usersTable.id, req.userId));
  const today = new Date();

  const last14 = new Date(today);
  last14.setDate(today.getDate() - 14);

  const meals = await db.select().from(mealsTable).where(
    and(
      eq(mealsTable.userId, req.userId),
      gte(mealsTable.date, last14.toISOString().split("T")[0])
    )
  );

  const target = user?.calorieTarget ?? 2000;
  const activeDays = new Set(meals.map(m => m.date)).size;
  const avgCalories = activeDays > 0 ? meals.reduce((s, m) => s + m.calories, 0) / activeDays : target;

  const trend = avgCalories < target * 0.9 ? "improving" : avgCalories > target * 1.1 ? "declining" : "stable";
  const projected7d = avgCalories * 0.97 + target * 0.03;
  const projected30d = avgCalories * 0.9 + target * 0.1;

  let goalCompletionDate: string | null = null;
  if (user?.goalDeadline) goalCompletionDate = user.goalDeadline;

  const recommendations = {
    improving: "Excellent progress! Keep consistent with your current eating patterns. You're trending toward your goal.",
    stable: "You're maintaining steady nutrition. Small adjustments to protein intake could accelerate your progress.",
    declining: "Consider reviewing your daily meal plan. Focus on hitting your calorie and protein targets consistently.",
  };

  res.json({
    projectedCalories7d: projected7d,
    projectedCalories30d: projected30d,
    goalCompletionDate,
    trend,
    recommendation: recommendations[trend],
  });
});

export default router;
