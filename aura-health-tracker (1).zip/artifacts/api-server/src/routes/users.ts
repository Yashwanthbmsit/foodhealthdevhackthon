import { Router, type IRouter } from "express";
import { eq } from "drizzle-orm";
import { db, usersTable } from "@workspace/db";
import { requireAuth } from "./auth";
import { CompleteOnboardingBody, UpdateUserProfileBody } from "@workspace/api-zod";

const router: IRouter = Router();

function formatProfile(user: any) {
  return {
    id: user.id,
    email: user.email,
    name: user.name,
    onboardingComplete: user.onboardingComplete,
    ageGroup: user.ageGroup ?? null,
    diet: user.diet ?? null,
    goal: user.goal ?? null,
    goalDeadline: user.goalDeadline ?? null,
    calorieTarget: user.calorieTarget ?? null,
    proteinTarget: user.proteinTarget ?? null,
    fatTarget: user.fatTarget ?? null,
    avatarUrl: user.avatarUrl ?? null,
  };
}

const GOAL_DEFAULTS: Record<string, { calories: number; protein: number; fat: number }> = {
  lose_weight: { calories: 1600, protein: 130, fat: 55 },
  gain_muscle: { calories: 2500, protein: 180, fat: 75 },
  maintain_weight: { calories: 2000, protein: 120, fat: 65 },
  improve_energy: { calories: 2100, protein: 110, fat: 70 },
  better_nutrition: { calories: 1900, protein: 120, fat: 65 },
};

router.post("/users/onboarding", requireAuth, async (req: any, res): Promise<void> => {
  const parsed = CompleteOnboardingBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const { ageGroup, diet, goal, goalDeadline, calorieTarget, proteinTarget, fatTarget } = parsed.data;
  const defaults = GOAL_DEFAULTS[goal] ?? GOAL_DEFAULTS.maintain_weight;

  const [user] = await db.update(usersTable).set({
    ageGroup,
    diet,
    goal,
    goalDeadline,
    calorieTarget: calorieTarget ?? defaults.calories,
    proteinTarget: proteinTarget ?? defaults.protein,
    fatTarget: fatTarget ?? defaults.fat,
    onboardingComplete: true,
  }).where(eq(usersTable.id, req.userId)).returning();

  res.json(formatProfile(user));
});

router.get("/users/profile", requireAuth, async (req: any, res): Promise<void> => {
  const [user] = await db.select().from(usersTable).where(eq(usersTable.id, req.userId));
  if (!user) { res.status(404).json({ error: "Not found" }); return; }
  res.json(formatProfile(user));
});

router.patch("/users/profile", requireAuth, async (req: any, res): Promise<void> => {
  const parsed = UpdateUserProfileBody.safeParse(req.body);
  if (!parsed.success) { res.status(400).json({ error: parsed.error.message }); return; }

  const [user] = await db.update(usersTable).set(parsed.data).where(eq(usersTable.id, req.userId)).returning();
  res.json(formatProfile(user));
});

export default router;
