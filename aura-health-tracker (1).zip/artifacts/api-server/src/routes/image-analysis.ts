import { Router, type IRouter } from "express";
import OpenAI from "openai";
import { requireAuth } from "./auth";

const router: IRouter = Router();

function getOpenAI() {
  return new OpenAI({
    apiKey: process.env.AI_INTEGRATIONS_OPENAI_API_KEY,
    baseURL: process.env.AI_INTEGRATIONS_OPENAI_BASE_URL,
  });
}

router.post("/food-analysis/analyze-image", requireAuth, async (req: any, res): Promise<void> => {
  const { imageBase64, mimeType } = req.body as { imageBase64?: string; mimeType?: string };

  if (!imageBase64 || !mimeType) {
    res.status(400).json({ error: "imageBase64 and mimeType are required" });
    return;
  }

  const dataUrl = `data:${mimeType};base64,${imageBase64}`;

  let completion: any;
  try {
    completion = await getOpenAI().chat.completions.create({
      model: "gpt-5",
      messages: [
        {
          role: "system",
          content: "You are a nutrition expert. When given a food image, respond ONLY with a valid JSON object — no markdown, no explanation, no extra text.",
        },
        {
          role: "user",
          content: [
            {
              type: "image_url",
              image_url: { url: dataUrl, detail: "low" } as any,
            },
            {
              type: "text",
              text: `Identify the food(s) in this image and estimate their nutrition. Return ONLY this JSON object:
{"name":"food name","calories":0,"protein":0,"fat":0,"carbs":0,"fiber":0,"category":"other","confidence":0.8,"servingSize":"1 serving","description":"brief description"}
Categories: protein, carbs, fats, vegetables, fruits, dairy, other. Sum all foods if multiple. Return ONLY JSON.`,
            },
          ],
        },
      ],
    });
  } catch (err: any) {
    req.log.error({ err: err?.message }, "OpenAI API call failed");
    res.status(500).json({ error: "AI service error", detail: err?.message });
    return;
  }

  const choice = completion.choices?.[0];
  req.log.info({ finish_reason: choice?.finish_reason, refusal: choice?.message?.refusal }, "AI image completion");

  const text: string = choice?.message?.content ?? choice?.message?.refusal ?? "";

  if (!text) {
    req.log.error({ choice: JSON.stringify(choice) }, "Empty AI response for image analysis");
    res.status(500).json({ error: "AI returned no content" });
    return;
  }

  let parsed: any;
  try {
    // Extract JSON from the response even if there's extra text
    const jsonMatch = text.match(/\{[\s\S]*\}/);
    if (!jsonMatch) throw new Error("No JSON object found in response");
    parsed = JSON.parse(jsonMatch[0]);
  } catch (e: any) {
    req.log.error({ text, err: e?.message }, "Failed to parse AI image analysis response");
    res.status(500).json({ error: "Could not parse AI response", raw: text.slice(0, 200) });
    return;
  }

  res.json({
    name: String(parsed.name ?? "Unknown Food"),
    calories: Number(parsed.calories ?? 0),
    protein: Number(parsed.protein ?? 0),
    fat: Number(parsed.fat ?? 0),
    carbs: Number(parsed.carbs ?? 0),
    fiber: Number(parsed.fiber ?? 0),
    category: String(parsed.category ?? "other"),
    confidence: Number(parsed.confidence ?? 0.7),
    servingSize: String(parsed.servingSize ?? "1 serving"),
    description: String(parsed.description ?? ""),
  });
});

export default router;
