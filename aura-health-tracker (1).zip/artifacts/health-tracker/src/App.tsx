import { Switch, Route, Router as WouterRouter, useLocation } from "wouter";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { AuthProvider, useAuth } from "./contexts/AuthContext";
import { useEffect, lazy, Suspense } from "react";
import NotFound from "@/pages/not-found";

const LoginPage = lazy(() => import("@/pages/login"));
const SignupPage = lazy(() => import("@/pages/signup"));
const OnboardingPage = lazy(() => import("@/pages/onboarding"));
const DashboardPage = lazy(() => import("@/pages/dashboard"));
const AnalysisPage = lazy(() => import("@/pages/analysis"));
const GoalsPage = lazy(() => import("@/pages/goals"));
const AnalyticsPage = lazy(() => import("@/pages/analytics"));
const NotificationsPage = lazy(() => import("@/pages/notifications"));

const queryClient = new QueryClient({
  defaultOptions: {
    queries: { retry: 1, staleTime: 30_000 },
  },
});

function PageLoader() {
  return (
    <div className="min-h-screen flex items-center justify-center bg-background">
      <div className="flex flex-col items-center gap-4">
        <div className="w-10 h-10 rounded-full border-2 border-primary/20 border-t-primary animate-spin" />
        <p className="text-xs text-muted-foreground tracking-widest uppercase">Loading</p>
      </div>
    </div>
  );
}

function ProtectedRoute({ component: Component }: { component: React.ComponentType }) {
  const { user, isLoading } = useAuth();
  const [, setLocation] = useLocation();

  useEffect(() => {
    if (!isLoading && !user) {
      setLocation("/login");
    } else if (!isLoading && user && !user.onboardingComplete) {
      setLocation("/onboarding");
    }
  }, [user, isLoading, setLocation]);

  if (isLoading) return <PageLoader />;
  if (!user || !user.onboardingComplete) return null;

  return <Component />;
}

function OnboardingRoute() {
  const { user, isLoading } = useAuth();
  const [, setLocation] = useLocation();

  useEffect(() => {
    if (!isLoading && !user) setLocation("/login");
    if (!isLoading && user && user.onboardingComplete) setLocation("/dashboard");
  }, [user, isLoading, setLocation]);

  if (isLoading) return <PageLoader />;
  if (!user || user.onboardingComplete) return null;

  return <OnboardingPage />;
}

function GuestRoute({ component: Component }: { component: React.ComponentType }) {
  const { user, isLoading } = useAuth();
  const [, setLocation] = useLocation();

  useEffect(() => {
    if (!isLoading && user) {
      setLocation(user.onboardingComplete ? "/dashboard" : "/onboarding");
    }
  }, [user, isLoading, setLocation]);

  if (isLoading) return <PageLoader />;
  if (user) return null;

  return <Component />;
}

function AppContent() {
  useEffect(() => {
    document.documentElement.classList.add("dark");
  }, []);

  return (
    <div className="min-h-screen bg-background text-foreground">
      {/* Ambient background blobs */}
      <div className="fixed inset-0 pointer-events-none overflow-hidden z-0">
        <div
          className="absolute w-[800px] h-[600px] rounded-full opacity-[0.04] blur-3xl"
          style={{
            background: "radial-gradient(ellipse, rgba(214,179,106,1), transparent)",
            top: "-20%", left: "30%",
          }}
        />
        <div
          className="absolute w-[600px] h-[400px] rounded-full opacity-[0.03] blur-3xl"
          style={{
            background: "radial-gradient(ellipse, rgba(214,179,106,1), transparent)",
            bottom: "10%", right: "-10%",
          }}
        />
      </div>

      <div className="relative z-10">
        <Suspense fallback={<PageLoader />}>
          <Switch>
            <Route path="/" component={() => {
              const [, setLocation] = useLocation();
              const { user, isLoading } = useAuth();
              useEffect(() => {
                if (!isLoading) {
                  if (!user) setLocation("/login");
                  else if (!user.onboardingComplete) setLocation("/onboarding");
                  else setLocation("/dashboard");
                }
              }, [user, isLoading]);
              return <PageLoader />;
            }} />
            <Route path="/login" component={() => <GuestRoute component={LoginPage} />} />
            <Route path="/signup" component={() => <GuestRoute component={SignupPage} />} />
            <Route path="/onboarding" component={OnboardingRoute} />
            <Route path="/dashboard" component={() => <ProtectedRoute component={DashboardPage} />} />
            <Route path="/analysis" component={() => <ProtectedRoute component={AnalysisPage} />} />
            <Route path="/goals" component={() => <ProtectedRoute component={GoalsPage} />} />
            <Route path="/analytics" component={() => <ProtectedRoute component={AnalyticsPage} />} />
            <Route path="/notifications" component={() => <ProtectedRoute component={NotificationsPage} />} />
            <Route component={NotFound} />
          </Switch>
        </Suspense>
      </div>
    </div>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, "")}>
          <AuthProvider>
            <AppContent />
          </AuthProvider>
        </WouterRouter>
        <Toaster />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
