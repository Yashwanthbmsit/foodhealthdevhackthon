import { motion } from "framer-motion";
import { BarChart3, TrendingUp, AlertTriangle, Brain } from "lucide-react";
import {
  useGetWeeklyAnalytics,
  useGetHealthRisks,
  useGetForecast,
} from "@workspace/api-client-react";
import {
  BarChart, Bar, LineChart, Line, XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid,
} from "recharts";
import { Navbar } from "@/components/Navbar";
import { VoiceAssistant } from "@/components/VoiceAssistant";

const CustomTooltip = ({ active, payload, label }: any) => {
  if (!active || !payload?.length) return null;
  return (
    <div className="glass-card rounded-xl p-3 border border-white/15 text-xs">
      <p className="text-muted-foreground mb-1">{label}</p>
      {payload.map((p: any) => (
        <p key={p.name} style={{ color: p.color }}>{p.name}: {Math.round(p.value)}</p>
      ))}
    </div>
  );
};

function RiskCard({ label, level, score, description }: { label: string; level: string; score: number; description: string }) {
  const color = level === "low" ? "#4ade80" : level === "moderate" ? "#D6B36A" : "#f87171";
  const bg = level === "low" ? "rgba(74,222,128,0.08)" : level === "moderate" ? "rgba(214,179,106,0.08)" : "rgba(248,113,113,0.08)";
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="glass-card rounded-2xl p-5 border border-white/8 relative overflow-hidden"
      style={{ borderTop: `2px solid ${color}50` }}
    >
      <div className="absolute top-0 left-0 right-0 h-16 opacity-30" style={{ background: `radial-gradient(ellipse at top, ${color}20, transparent)` }} />
      <div className="relative">
        <div className="flex items-start justify-between mb-3">
          <div>
            <p className="text-xs text-muted-foreground uppercase tracking-widest mb-1">{label}</p>
            <span className="text-sm font-semibold capitalize px-2.5 py-0.5 rounded-full" style={{ color, backgroundColor: bg }}>
              {level} risk
            </span>
          </div>
          <div className="text-right">
            <div className="relative w-12 h-12">
              <svg viewBox="0 0 48 48" className="w-12 h-12" style={{ transform: "rotate(-90deg)" }}>
                <circle cx="24" cy="24" r="18" fill="none" stroke="rgba(255,255,255,0.06)" strokeWidth="4" />
                <circle
                  cx="24" cy="24" r="18" fill="none" stroke={color} strokeWidth="4"
                  strokeDasharray={`${2 * Math.PI * 18}`}
                  strokeDashoffset={`${2 * Math.PI * 18 * (1 - score / 100)}`}
                  strokeLinecap="round"
                />
              </svg>
              <div className="absolute inset-0 flex items-center justify-center" style={{ transform: "rotate(0deg)" }}>
                <span className="text-xs font-bold" style={{ color }}>{Math.round(score)}</span>
              </div>
            </div>
          </div>
        </div>
        <p className="text-xs text-muted-foreground leading-relaxed">{description}</p>
      </div>
    </motion.div>
  );
}

export default function AnalyticsPage() {
  const { data: weekly, isLoading: weeklyLoading } = useGetWeeklyAnalytics();
  const { data: risks, isLoading: risksLoading } = useGetHealthRisks();
  const { data: forecast } = useGetForecast();

  const chartData = weekly?.dailyData?.map(d => ({
    date: new Date(d.date).toLocaleDateString("en", { weekday: "short" }),
    Calories: Math.round(d.calories),
    Protein: Math.round(d.protein),
    Fat: Math.round(d.fat),
  })) ?? [];

  return (
    <div className="min-h-screen ambient-bg">
      <Navbar />
      <div className="pt-20 pb-16 max-w-6xl mx-auto px-6">
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="mb-10">
          <p className="text-xs text-muted-foreground uppercase tracking-widest mb-2">Intelligence</p>
          <h1 className="font-serif text-5xl text-foreground mb-1">Weekly <span className="text-gold">Analytics</span></h1>
          <p className="text-muted-foreground">AI-powered insights into your nutrition and health patterns</p>
        </motion.div>

        {/* Stats row */}
        {weekly && (
          <motion.div
            initial={{ opacity: 0, y: 15 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 }}
            className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8"
          >
            {[
              { label: "Avg Calories", value: `${Math.round(weekly.averages?.calories ?? 0)}`, unit: "kcal/day", color: "#D6B36A" },
              { label: "Avg Protein", value: `${Math.round(weekly.averages?.protein ?? 0)}`, unit: "g/day", color: "#60a5fa" },
              { label: "Avg Fat", value: `${Math.round(weekly.averages?.fat ?? 0)}`, unit: "g/day", color: "#f87171" },
              { label: "Day streak", value: `${weekly.streak}`, unit: "days", color: "#4ade80" },
            ].map((stat, i) => (
              <motion.div
                key={stat.label}
                initial={{ opacity: 0, scale: 0.96 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ delay: 0.15 + i * 0.06 }}
                data-testid={`stat-${stat.label.toLowerCase().replace(" ", "-")}`}
                className="glass-card rounded-2xl p-4 border border-white/8"
              >
                <p className="text-xs text-muted-foreground mb-1">{stat.label}</p>
                <div className="flex items-baseline gap-1">
                  <span className="text-2xl font-semibold" style={{ color: stat.color }}>{stat.value}</span>
                  <span className="text-xs text-muted-foreground">{stat.unit}</span>
                </div>
              </motion.div>
            ))}
          </motion.div>
        )}

        {/* Charts */}
        <div className="grid lg:grid-cols-2 gap-6 mb-8">
          {/* Bar chart — calories */}
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.2 }}
            className="glass-card rounded-2xl p-6 border border-white/8"
          >
            <div className="flex items-center gap-2 mb-5">
              <BarChart3 size={16} className="text-gold" />
              <h3 className="font-medium text-foreground text-sm">Daily Calories</h3>
            </div>
            {weeklyLoading ? (
              <div className="h-48 animate-pulse bg-white/3 rounded-xl" />
            ) : (
              <ResponsiveContainer width="100%" height={180}>
                <BarChart data={chartData} barSize={20}>
                  <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.05)" vertical={false} />
                  <XAxis dataKey="date" tick={{ fill: "#9CA3AF", fontSize: 11 }} axisLine={false} tickLine={false} />
                  <YAxis tick={{ fill: "#9CA3AF", fontSize: 11 }} axisLine={false} tickLine={false} />
                  <Tooltip content={<CustomTooltip />} />
                  <Bar dataKey="Calories" fill="#D6B36A" radius={[4,4,0,0]} fillOpacity={0.85} />
                </BarChart>
              </ResponsiveContainer>
            )}
          </motion.div>

          {/* Line chart — macros */}
          <motion.div
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.25 }}
            className="glass-card rounded-2xl p-6 border border-white/8"
          >
            <div className="flex items-center gap-2 mb-2">
              <TrendingUp size={16} className="text-gold" />
              <h3 className="font-medium text-foreground text-sm">Protein &amp; Fat Trends</h3>
            </div>
            <div className="flex gap-4 mb-3">
              {[{ label: "Protein", color: "#60a5fa" }, { label: "Fat", color: "#f87171" }].map(l => (
                <div key={l.label} className="flex items-center gap-1.5">
                  <div className="w-3 h-0.5 rounded-full" style={{ backgroundColor: l.color }} />
                  <span className="text-xs text-muted-foreground">{l.label}</span>
                </div>
              ))}
            </div>
            {weeklyLoading ? (
              <div className="h-48 animate-pulse bg-white/3 rounded-xl" />
            ) : (
              <ResponsiveContainer width="100%" height={180}>
                <LineChart data={chartData}>
                  <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.05)" vertical={false} />
                  <XAxis dataKey="date" tick={{ fill: "#9CA3AF", fontSize: 11 }} axisLine={false} tickLine={false} />
                  <YAxis tick={{ fill: "#9CA3AF", fontSize: 11 }} axisLine={false} tickLine={false} />
                  <Tooltip content={<CustomTooltip />} />
                  <Line type="monotone" dataKey="Protein" stroke="#60a5fa" strokeWidth={2} dot={false} />
                  <Line type="monotone" dataKey="Fat" stroke="#f87171" strokeWidth={2} dot={false} />
                </LineChart>
              </ResponsiveContainer>
            )}
          </motion.div>
        </div>

        {/* AI Insights */}
        {weekly?.insights && weekly.insights.length > 0 && (
          <motion.div
            initial={{ opacity: 0, y: 15 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.35 }}
            className="glass-card rounded-2xl p-6 border border-white/8 mb-8"
          >
            <div className="flex items-center gap-2 mb-4">
              <Brain size={16} className="text-gold" />
              <h3 className="font-medium text-foreground text-sm">AI Insights</h3>
            </div>
            <div className="grid md:grid-cols-2 gap-3">
              {weekly.insights.map((insight, i) => (
                <div key={i} className="flex items-start gap-2.5 text-sm text-muted-foreground">
                  <div className="w-1.5 h-1.5 rounded-full bg-primary mt-1.5 flex-shrink-0" />
                  {insight}
                </div>
              ))}
            </div>
          </motion.div>
        )}

        {/* Health Risks */}
        <div className="mb-6">
          <div className="flex items-center gap-2 mb-4">
            <AlertTriangle size={15} className="text-gold" />
            <p className="text-xs text-muted-foreground uppercase tracking-widest">Health Risk Assessment</p>
          </div>
          {risksLoading ? (
            <div className="grid md:grid-cols-3 gap-4">
              {[1,2,3].map(i => <div key={i} className="h-36 glass-card rounded-2xl animate-pulse border border-white/5" />)}
            </div>
          ) : risks ? (
            <div className="grid md:grid-cols-3 gap-4">
              <RiskCard label="Obesity Risk" level={risks.obesityRisk.level ?? "low"} score={risks.obesityRisk.score ?? 0} description={risks.obesityRisk.description ?? ""} />
              <RiskCard label="Energy/Weakness Risk" level={risks.weaknessRisk.level ?? "low"} score={risks.weaknessRisk.score ?? 0} description={risks.weaknessRisk.description ?? ""} />
              <RiskCard label="Diabetes Risk" level={risks.diabetesRisk.level ?? "low"} score={risks.diabetesRisk.score ?? 0} description={risks.diabetesRisk.description ?? ""} />
            </div>
          ) : null}
        </div>

        {/* Forecast */}
        {forecast && (
          <motion.div
            initial={{ opacity: 0, y: 15 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.5 }}
            className="glass-card rounded-2xl p-6 border border-primary/15"
            style={{ background: "rgba(214,179,106,0.03)" }}
          >
            <div className="flex items-center gap-2 mb-3">
              <TrendingUp size={15} className="text-gold" />
              <h3 className="text-sm font-medium text-gold">30-Day Forecast</h3>
            </div>
            <div className="grid md:grid-cols-3 gap-4">
              <div>
                <p className="text-xs text-muted-foreground mb-1">7-day projection</p>
                <p className="text-xl font-semibold text-foreground">{Math.round(forecast.projectedCalories7d)} <span className="text-sm text-muted-foreground font-normal">kcal/day</span></p>
              </div>
              <div>
                <p className="text-xs text-muted-foreground mb-1">30-day projection</p>
                <p className="text-xl font-semibold text-foreground">{Math.round(forecast.projectedCalories30d)} <span className="text-sm text-muted-foreground font-normal">kcal/day</span></p>
              </div>
              <div>
                <p className="text-xs text-muted-foreground mb-1">Trend</p>
                <p className="text-xl font-semibold capitalize" style={{ color: forecast.trend === "improving" ? "#4ade80" : forecast.trend === "declining" ? "#f87171" : "#D6B36A" }}>{forecast.trend}</p>
              </div>
            </div>
          </motion.div>
        )}
      </div>
      <VoiceAssistant />
    </div>
  );
}
