import { useState, useRef, useCallback } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Upload, Scan, Zap, Plus, X, ImageIcon, Camera } from "lucide-react";
import { useAnalyzeFood, useCreateMeal } from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { Navbar } from "@/components/Navbar";
import { VoiceAssistant } from "@/components/VoiceAssistant";
import { useToast } from "@/hooks/use-toast";

const PERIODS = ["morning", "afternoon", "evening", "night"] as const;

const MAX_FILE_SIZE = 10 * 1024 * 1024; // 10 MB
const ACCEPTED_TYPES = ["image/jpeg", "image/png", "image/webp", "image/gif"];

async function analyzeImageViaAI(imageBase64: string, mimeType: string): Promise<any> {
  const token = localStorage.getItem("auth_token");
  const res = await fetch("/api/food-analysis/analyze-image", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      ...(token ? { Authorization: `Bearer ${token}` } : {}),
    },
    body: JSON.stringify({ imageBase64, mimeType }),
  });
  if (!res.ok) throw new Error("Image analysis failed");
  return res.json();
}

function resizeAndEncode(file: File, maxPx = 512, quality = 0.75): Promise<{ base64: string; mimeType: string }> {
  return new Promise((resolve, reject) => {
    const img = new Image();
    const objectUrl = URL.createObjectURL(file);
    img.onload = () => {
      URL.revokeObjectURL(objectUrl);
      const scale = Math.min(1, maxPx / Math.max(img.width, img.height));
      const w = Math.round(img.width * scale);
      const h = Math.round(img.height * scale);
      const canvas = document.createElement("canvas");
      canvas.width = w;
      canvas.height = h;
      const ctx = canvas.getContext("2d")!;
      ctx.drawImage(img, 0, 0, w, h);
      const dataUrl = canvas.toDataURL("image/jpeg", quality);
      resolve({ base64: dataUrl.split(",")[1], mimeType: "image/jpeg" });
    };
    img.onerror = reject;
    img.src = objectUrl;
  });
}

export default function AnalysisPage() {
  const [description, setDescription] = useState("");
  const [selectedPeriod, setSelectedPeriod] = useState<typeof PERIODS[number]>("morning");
  const [result, setResult] = useState<any>(null);
  const [scanning, setScanning] = useState(false);
  const [uploadedImage, setUploadedImage] = useState<{ file: File; preview: string } | null>(null);
  const [isDragOver, setIsDragOver] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const analyzeFood = useAnalyzeFood();
  const createMeal = useCreateMeal();
  const queryClient = useQueryClient();
  const { toast } = useToast();

  const handleFile = useCallback((file: File) => {
    if (!ACCEPTED_TYPES.includes(file.type)) {
      toast({ title: "Unsupported format", description: "Please upload a JPG, PNG, WebP, or GIF image.", variant: "destructive" });
      return;
    }
    if (file.size > MAX_FILE_SIZE) {
      toast({ title: "File too large", description: "Please upload an image smaller than 10 MB.", variant: "destructive" });
      return;
    }
    const preview = URL.createObjectURL(file);
    setUploadedImage({ file, preview });
    setResult(null);
  }, [toast]);

  const handleDrop = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setIsDragOver(false);
    const file = e.dataTransfer.files[0];
    if (file) handleFile(file);
  }, [handleFile]);

  const handleDragOver = (e: React.DragEvent) => { e.preventDefault(); setIsDragOver(true); };
  const handleDragLeave = () => setIsDragOver(false);

  const handleFileInput = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) handleFile(file);
    e.target.value = "";
  };

  const removeImage = () => {
    if (uploadedImage) URL.revokeObjectURL(uploadedImage.preview);
    setUploadedImage(null);
  };

  const handleAnalyze = async () => {
    if (!description.trim() && !uploadedImage) return;
    setResult(null);
    setScanning(true);

    if (uploadedImage) {
      try {
        const { base64, mimeType: resizedMime } = await resizeAndEncode(uploadedImage.file);
        const data = await analyzeImageViaAI(base64, resizedMime);
        setResult(data);
        if (description.trim()) setDescription("");
      } catch {
        toast({ title: "Image analysis failed", description: "Could not analyze the image. Try describing the food instead.", variant: "destructive" });
      } finally {
        setScanning(false);
      }
    } else {
      analyzeFood.mutate({ data: { description } }, {
        onSuccess: (res) => { setResult(res); setScanning(false); },
        onError: () => {
          setScanning(false);
          toast({ title: "Analysis failed", description: "Could not analyze the food item.", variant: "destructive" });
        }
      });
    }
  };

  const handleAddToLog = () => {
    if (!result) return;
    const today = new Date().toISOString().split("T")[0];
    createMeal.mutate({
      data: {
        name: result.name,
        calories: result.calories,
        protein: result.protein,
        fat: result.fat,
        carbs: result.carbs,
        category: result.category,
        period: selectedPeriod,
        date: today,
      }
    }, {
      onSuccess: () => {
        queryClient.invalidateQueries({ queryKey: ["/api/meals"] });
        queryClient.invalidateQueries({ queryKey: ["/api/meals/summary"] });
        toast({ title: "Added to your log", description: `${result.name} added to ${selectedPeriod}` });
        setResult(null);
        setDescription("");
        removeImage();
      }
    });
  };

  const confidenceColor = (c: number) => {
    if (c > 0.8) return "#4ade80";
    if (c > 0.6) return "#D6B36A";
    return "#f87171";
  };

  const canAnalyze = (description.trim().length > 0 || !!uploadedImage) && !scanning && !analyzeFood.isPending;

  return (
    <div className="min-h-screen ambient-bg">
      <Navbar />
      <div className="pt-20 pb-16 max-w-4xl mx-auto px-6">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          className="mb-10"
        >
          <p className="text-xs text-muted-foreground uppercase tracking-widest mb-2">AI Analysis</p>
          <h1 className="font-serif text-5xl text-foreground mb-3">Food <span className="text-gold">Scanner</span></h1>
          <p className="text-muted-foreground">Upload a photo or describe any food — AI will instantly calculate its nutritional profile</p>
        </motion.div>

        <div className="grid lg:grid-cols-2 gap-8">
          {/* Input panel */}
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.15 }}
            className="glass-card rounded-2xl p-6 border border-white/8"
          >
            <div className="flex items-center gap-2 mb-5">
              <div className="w-8 h-8 rounded-lg bg-primary/10 flex items-center justify-center">
                <Zap size={15} className="text-gold" />
              </div>
              <h3 className="font-medium text-foreground">Describe or upload food</h3>
            </div>

            {/* Image upload area */}
            <input
              ref={fileInputRef}
              type="file"
              accept="image/jpeg,image/png,image/webp,image/gif"
              className="hidden"
              onChange={handleFileInput}
            />

            <AnimatePresence mode="wait">
              {uploadedImage ? (
                <motion.div
                  key="preview"
                  initial={{ opacity: 0, scale: 0.95 }}
                  animate={{ opacity: 1, scale: 1 }}
                  exit={{ opacity: 0, scale: 0.95 }}
                  className="relative mb-4 rounded-xl overflow-hidden border border-white/15 group"
                >
                  <img
                    src={uploadedImage.preview}
                    alt="Food preview"
                    className="w-full h-44 object-cover"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent" />
                  <div className="absolute bottom-3 left-3 flex items-center gap-2">
                    <Camera size={13} className="text-white/70" />
                    <span className="text-xs text-white/80 truncate max-w-[160px]">{uploadedImage.file.name}</span>
                  </div>
                  <button
                    onClick={removeImage}
                    className="absolute top-2 right-2 w-7 h-7 rounded-full bg-black/60 border border-white/20 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity hover:bg-red-500/60"
                  >
                    <X size={13} className="text-white" />
                  </button>
                </motion.div>
              ) : (
                <motion.div
                  key="dropzone"
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  exit={{ opacity: 0 }}
                  onClick={() => fileInputRef.current?.click()}
                  onDrop={handleDrop}
                  onDragOver={handleDragOver}
                  onDragLeave={handleDragLeave}
                  className={`border border-dashed rounded-xl p-6 text-center mb-4 cursor-pointer transition-all group ${
                    isDragOver
                      ? "border-primary/60 bg-primary/5"
                      : "border-white/15 hover:border-primary/30 hover:bg-white/3"
                  }`}
                >
                  <motion.div
                    animate={isDragOver ? { scale: 1.1 } : { scale: 1 }}
                    className="flex flex-col items-center"
                  >
                    <div className={`w-10 h-10 rounded-xl flex items-center justify-center mb-2 transition-colors ${
                      isDragOver ? "bg-primary/20" : "bg-white/5 group-hover:bg-primary/10"
                    }`}>
                      <ImageIcon size={18} className={`transition-colors ${isDragOver ? "text-primary" : "text-muted-foreground group-hover:text-primary/60"}`} />
                    </div>
                    <p className="text-xs font-medium text-muted-foreground group-hover:text-foreground/70 transition-colors">
                      {isDragOver ? "Drop to analyze" : "Click or drag image here"}
                    </p>
                    <p className="text-xs text-muted-foreground/50 mt-0.5">JPG, PNG, WebP · max 10 MB</p>
                  </motion.div>
                </motion.div>
              )}
            </AnimatePresence>

            {/* Divider */}
            <div className="flex items-center gap-3 mb-4">
              <div className="flex-1 h-px bg-white/8" />
              <span className="text-xs text-muted-foreground/50">or describe</span>
              <div className="flex-1 h-px bg-white/8" />
            </div>

            <textarea
              data-testid="input-food-description"
              value={description}
              onChange={e => setDescription(e.target.value)}
              onKeyDown={e => e.key === "Enter" && e.ctrlKey && handleAnalyze()}
              placeholder="e.g. 2 dosas with sambar, bowl of chicken rice, 1 cup oatmeal with banana..."
              rows={4}
              className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 text-foreground placeholder:text-muted-foreground outline-none focus:border-primary/50 transition-all text-sm resize-none mb-4"
            />

            <motion.button
              data-testid="btn-analyze-food"
              onClick={handleAnalyze}
              disabled={!canAnalyze}
              className="w-full flex items-center justify-center gap-2 py-3.5 rounded-xl font-semibold text-sm disabled:opacity-40 transition-all"
              style={{ background: "linear-gradient(135deg, #D6B36A, #a8853f)" }}
              whileHover={{ scale: canAnalyze ? 1.01 : 1, boxShadow: canAnalyze ? "0 0 25px rgba(214,179,106,0.3)" : "none" }}
              whileTap={{ scale: canAnalyze ? 0.99 : 1 }}
            >
              {scanning ? (
                <>
                  <div className="w-4 h-4 border-2 border-black/30 border-t-black rounded-full animate-spin" />
                  <span className="text-black">
                    {uploadedImage ? "Analyzing image…" : "Analyzing…"}
                  </span>
                </>
              ) : (
                <>
                  {uploadedImage ? <Camera size={16} className="text-black" /> : <Scan size={16} className="text-black" />}
                  <span className="text-black">
                    {uploadedImage ? "Analyze Image" : "Analyze Food"}
                  </span>
                </>
              )}
            </motion.button>
          </motion.div>

          {/* Scanner / Result panel */}
          <motion.div
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.2 }}
            className="glass-card rounded-2xl border border-white/8 overflow-hidden"
          >
            <AnimatePresence mode="wait">
              {scanning && (
                <motion.div
                  key="scanning"
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  exit={{ opacity: 0 }}
                  className="h-full flex flex-col items-center justify-center p-8 relative min-h-[340px]"
                >
                  {uploadedImage ? (
                    <div className="relative w-44 h-44 mb-6 rounded-xl overflow-hidden">
                      <img src={uploadedImage.preview} alt="" className="w-full h-full object-cover" />
                      <div className="absolute inset-0 border-2 border-primary/60 rounded-xl" />
                      <div className="absolute top-0 left-0 w-5 h-5 border-t-2 border-l-2 border-primary" />
                      <div className="absolute top-0 right-0 w-5 h-5 border-t-2 border-r-2 border-primary" />
                      <div className="absolute bottom-0 left-0 w-5 h-5 border-b-2 border-l-2 border-primary" />
                      <div className="absolute bottom-0 right-0 w-5 h-5 border-b-2 border-r-2 border-primary" />
                      <motion.div
                        className="absolute left-0 right-0 h-0.5 bg-gradient-to-r from-transparent via-primary to-transparent"
                        animate={{ top: ["5%", "95%", "5%"] }}
                        transition={{ duration: 2, repeat: Infinity, ease: "easeInOut" }}
                      />
                    </div>
                  ) : (
                    <div className="relative w-48 h-48 mb-6">
                      <div className="absolute inset-0 border-2 border-primary/40 rounded-xl" />
                      <div className="absolute top-0 left-0 w-6 h-6 border-t-2 border-l-2 border-primary rounded-tl-xl" />
                      <div className="absolute top-0 right-0 w-6 h-6 border-t-2 border-r-2 border-primary rounded-tr-xl" />
                      <div className="absolute bottom-0 left-0 w-6 h-6 border-b-2 border-l-2 border-primary rounded-bl-xl" />
                      <div className="absolute bottom-0 right-0 w-6 h-6 border-b-2 border-r-2 border-primary rounded-br-xl" />
                      <motion.div
                        className="absolute left-2 right-2 h-0.5 bg-gradient-to-r from-transparent via-primary to-transparent"
                        animate={{ top: ["10%", "90%", "10%"] }}
                        transition={{ duration: 2, repeat: Infinity, ease: "easeInOut" }}
                      />
                      <div className="absolute inset-0 flex items-center justify-center">
                        <Scan size={40} className="text-primary/30" />
                      </div>
                    </div>
                  )}
                  <p className="text-sm text-muted-foreground text-center">
                    {uploadedImage ? "AI reading your food photo…" : "AI analyzing nutritional profile…"}
                  </p>
                  <div className="flex gap-1 mt-3">
                    {[0, 1, 2].map(i => (
                      <motion.div
                        key={i}
                        className="w-1.5 h-1.5 rounded-full bg-primary"
                        animate={{ opacity: [0.3, 1, 0.3] }}
                        transition={{ duration: 1, delay: i * 0.2, repeat: Infinity }}
                      />
                    ))}
                  </div>
                </motion.div>
              )}

              {result && !scanning && (
                <motion.div
                  key="result"
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0 }}
                  className="p-6"
                >
                  <div className="flex items-start justify-between mb-5">
                    <div>
                      <p className="text-xs text-muted-foreground uppercase tracking-widest mb-1">Analysis Complete</p>
                      <h3 className="font-serif text-2xl text-foreground">{result.name}</h3>
                      <div className="flex items-center gap-2 mt-1">
                        <span className="text-xs text-muted-foreground px-2 py-0.5 rounded-full bg-white/5 border border-white/10 inline-block capitalize">
                          {result.category}
                        </span>
                        {result.servingSize && (
                          <span className="text-xs text-muted-foreground/60">{result.servingSize}</span>
                        )}
                      </div>
                    </div>
                    <div className="text-right">
                      <p className="text-xs text-muted-foreground mb-1">Confidence</p>
                      <div className="flex items-center gap-1.5">
                        <div className="w-12 h-1 rounded-full bg-white/10 overflow-hidden">
                          <div className="h-full rounded-full" style={{ width: `${(result.confidence ?? 0.85) * 100}%`, backgroundColor: confidenceColor(result.confidence ?? 0.85) }} />
                        </div>
                        <span className="text-xs font-medium" style={{ color: confidenceColor(result.confidence ?? 0.85) }}>
                          {Math.round((result.confidence ?? 0.85) * 100)}%
                        </span>
                      </div>
                    </div>
                  </div>

                  {/* Macros */}
                  <div className="grid grid-cols-4 gap-3 mb-4">
                    {[
                      { label: "Calories", value: Math.round(result.calories), unit: "kcal", color: "#D6B36A" },
                      { label: "Protein", value: Math.round(result.protein), unit: "g", color: "#60a5fa" },
                      { label: "Fat", value: Math.round(result.fat), unit: "g", color: "#f87171" },
                      { label: "Carbs", value: Math.round(result.carbs), unit: "g", color: "#4ade80" },
                    ].map(macro => (
                      <div
                        key={macro.label}
                        data-testid={`macro-${macro.label.toLowerCase()}`}
                        className="glass-card rounded-xl p-3 text-center border border-white/8"
                      >
                        <div className="text-lg font-semibold" style={{ color: macro.color }}>{macro.value}</div>
                        <div className="text-xs text-muted-foreground">{macro.unit}</div>
                        <div className="text-xs text-muted-foreground/70">{macro.label}</div>
                      </div>
                    ))}
                  </div>

                  {/* Description from AI */}
                  {result.description && (
                    <p className="text-xs text-muted-foreground/80 mb-4 leading-relaxed border-l-2 border-primary/30 pl-3">
                      {result.description}
                    </p>
                  )}

                  {/* Insights */}
                  {result.insights && result.insights.length > 0 && (
                    <div className="mb-4">
                      <p className="text-xs text-muted-foreground mb-2">AI Insights</p>
                      <div className="space-y-1.5">
                        {result.insights.map((insight: string, i: number) => (
                          <div key={i} className="flex items-start gap-2 text-xs text-muted-foreground">
                            <div className="w-1 h-1 rounded-full bg-primary mt-1.5 flex-shrink-0" />
                            {insight}
                          </div>
                        ))}
                      </div>
                    </div>
                  )}

                  {/* Add to log */}
                  <div className="border-t border-white/8 pt-4">
                    <p className="text-xs text-muted-foreground mb-2">Add to meal period</p>
                    <div className="flex gap-2 mb-3">
                      {PERIODS.map(p => (
                        <button
                          key={p}
                          data-testid={`period-${p}`}
                          onClick={() => setSelectedPeriod(p)}
                          className={`flex-1 py-1.5 rounded-lg text-xs font-medium capitalize transition-all ${
                            selectedPeriod === p
                              ? "bg-primary text-primary-foreground"
                              : "bg-white/5 text-muted-foreground hover:bg-white/10"
                          }`}
                        >
                          {p}
                        </button>
                      ))}
                    </div>
                    <motion.button
                      data-testid="btn-add-to-log"
                      onClick={handleAddToLog}
                      disabled={createMeal.isPending}
                      className="w-full flex items-center justify-center gap-2 py-2.5 rounded-xl border border-primary/40 text-gold text-sm font-medium hover:bg-primary/10 transition-all disabled:opacity-50"
                      whileHover={{ scale: 1.01 }}
                      whileTap={{ scale: 0.99 }}
                    >
                      <Plus size={14} />
                      Add to {selectedPeriod}
                    </motion.button>
                  </div>
                </motion.div>
              )}

              {!result && !scanning && (
                <motion.div
                  key="empty"
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  className="h-full flex flex-col items-center justify-center p-8 text-center min-h-[340px]"
                >
                  <div className="w-16 h-16 rounded-full bg-primary/5 border border-primary/20 flex items-center justify-center mb-4">
                    <Scan size={28} className="text-primary/40" />
                  </div>
                  <p className="text-sm text-muted-foreground max-w-[200px]">Upload a food photo or type a description, then hit Analyze</p>
                </motion.div>
              )}
            </AnimatePresence>
          </motion.div>
        </div>

        {/* Quick examples */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4 }}
          className="mt-8"
        >
          <p className="text-xs text-muted-foreground uppercase tracking-widest mb-3">Quick text examples</p>
          <div className="flex flex-wrap gap-2">
            {["2 dosas with sambar", "Grilled chicken 200g", "Bowl of oatmeal with banana", "Avocado toast 2 slices", "Protein shake 350ml"].map(ex => (
              <button
                key={ex}
                onClick={() => { setDescription(ex); removeImage(); }}
                className="text-xs px-3 py-1.5 rounded-full border border-white/10 text-muted-foreground hover:text-foreground hover:border-primary/30 transition-all"
              >
                {ex}
              </button>
            ))}
          </div>
        </motion.div>
      </div>
      <VoiceAssistant />
    </div>
  );
}
