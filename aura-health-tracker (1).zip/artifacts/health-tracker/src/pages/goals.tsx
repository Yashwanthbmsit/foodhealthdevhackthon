import { motion } from "framer-motion";
import { Target, Calendar, TrendingUp, Flame, Dumbbell, Droplets } from "lucide-react";
import { useGetGoals, useGetForecast, useUpdateGoals, getGetGoalsQueryKey } from "@workspace/api-client-react";
import { Navbar } from "@/components/Navbar";
import { VoiceAssistant } from "@/components/VoiceAssistant";
import { useQueryClient } from "@tanstack/react-query";
import { useState } from "react";
import { useToast } from "@/hooks/use-toast";

function RadialProgress({ value, max, color, size = 80 }: { value: number; max: number; color: string; size?: number }) {
  const pct = Math.min(100, max > 0 ? (value / max) * 100 : 0);
  const r = (size / 2) - 8;
  const circ = 2 * Math.PI * r;
  const offset = circ - (pct / 100) * circ;
  return (
    <svg width={size} height={size} viewBox={`0 0 ${size} ${size}`} style={{ transform: "rotate(-90deg)" }}>
      <circle cx={size/2} cy={size/2} r={r} fill="none" stroke="rgba(255,255,255,0.06)" strokeWidth={6} />
      <circle
        cx={size/2} cy={size/2} r={r}
        fill="none" stroke={color} strokeWidth={6}
        strokeDasharray={circ}
        strokeDashoffset={offset}
        strokeLinecap="round"
        style={{ transition: "stroke-dashoffset 1s ease" }}
      />
    </svg>
  );
}

function MacroCard({ icon: Icon, label, consumed, target, unit, color }: any) {
  const pct = Math.min(100, target > 0 ? (consumed / target) * 100 : 0);
  const remaining = Math.max(0, target - consumed);
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="glass-card rounded-2xl p-5 border border-white/8"
    >
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 rounded-lg flex items-center justify-center" style={{ backgroundColor: `${color}15` }}>
            <Icon size={15} style={{ color }} />
          </div>
          <span className="font-medium text-sm text-foreground">{label}</span>
        </div>
        <div className="relative">
          <RadialProgress value={consumed} max={target} color={color} size={56} />
          <div className="absolute inset-0 flex items-center justify-center">
            <span className="text-xs font-bold" style={{ color }}>{Math.round(pct)}%</span>
          </div>
        </div>
      </div>

      <div className="mb-3">
        <div className="flex justify-between text-xs text-muted-foreground mb-1.5">
          <span>{Math.round(consumed)}{unit} consumed</span>
          <span>{Math.round(target)}{unit} target</span>
        </div>
        <div className="h-1.5 bg-white/8 rounded-full overflow-hidden">
          <motion.div
            className="h-full rounded-full"
            style={{ backgroundColor: color }}
            initial={{ width: 0 }}
            animate={{ width: `${pct}%` }}
            transition={{ duration: 1, ease: "easeOut" }}
          />
        </div>
      </div>

      <div className="flex justify-between">
        <div>
          <p className="text-xs text-muted-foreground">Remaining</p>
          <p className="text-lg font-semibold" style={{ color }}>{Math.round(remaining)}{unit}</p>
        </div>
        <div className="text-right">
          <p className="text-xs text-muted-foreground">Consumed</p>
          <p className="text-lg font-semibold text-foreground">{Math.round(consumed)}{unit}</p>
        </div>
      </div>
    </motion.div>
  );
}

export default function GoalsPage() {
  const { data: goals, isLoading } = useGetGoals();
  const { data: forecast } = useGetForecast();
  const updateGoals = useUpdateGoals();
  const queryClient = useQueryClient();
  const { toast } = useToast();
  const [editing, setEditing] = useState(false);
  const [form, setForm] = useState({ calorieTarget: "", proteinTarget: "", fatTarget: "" });

  const handleEdit = () => {
    setForm({
      calorieTarget: String(goals?.calorieTarget ?? 2000),
      proteinTarget: String(goals?.proteinTarget ?? 120),
      fatTarget: String(goals?.fatTarget ?? 65),
    });
    setEditing(true);
  };

  const handleSave = () => {
    updateGoals.mutate({
      data: {
        calorieTarget: Number(form.calorieTarget),
        proteinTarget: Number(form.proteinTarget),
        fatTarget: Number(form.fatTarget),
      }
    }, {
      onSuccess: () => {
        queryClient.invalidateQueries({ queryKey: getGetGoalsQueryKey() });
        setEditing(false);
        toast({ title: "Goals updated" });
      }
    });
  };

  const daysLeft = goals?.daysUntilDeadline;

  const trendColor = forecast?.trend === "improving" ? "#4ade80" : forecast?.trend === "declining" ? "#f87171" : "#D6B36A";

  return (
    <div className="min-h-screen ambient-bg">
      <Navbar />
      <div className="pt-20 pb-16 max-w-6xl mx-auto px-6">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="flex items-start justify-between mb-10"
        >
          <div>
            <p className="text-xs text-muted-foreground uppercase tracking-widest mb-2">Progress</p>
            <h1 className="font-serif text-5xl text-foreground mb-1">Your <span className="text-gold">Goals</span></h1>
            <p className="text-muted-foreground">Track your daily nutrition targets and long-term progress</p>
          </div>
          <button
            data-testid="btn-edit-goals"
            onClick={editing ? handleSave : handleEdit}
            className="px-4 py-2 rounded-xl border border-primary/30 text-gold text-sm hover:bg-primary/10 transition-all"
          >
            {editing ? "Save" : "Edit goals"}
          </button>
        </motion.div>

        {/* Edit form */}
        {editing && (
          <motion.div
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            className="glass-card rounded-2xl p-5 mb-6 border border-primary/20"
          >
            <h3 className="text-sm font-medium text-gold mb-4">Update daily targets</h3>
            <div className="grid grid-cols-3 gap-4">
              {[
                { key: "calorieTarget", label: "Calorie target", unit: "kcal" },
                { key: "proteinTarget", label: "Protein target", unit: "g" },
                { key: "fatTarget", label: "Fat target", unit: "g" },
              ].map(({ key, label, unit }) => (
                <div key={key}>
                  <label className="block text-xs text-muted-foreground mb-1.5">{label}</label>
                  <div className="relative">
                    <input
                      data-testid={`input-${key}`}
                      type="number"
                      value={form[key as keyof typeof form]}
                      onChange={e => setForm(f => ({ ...f, [key]: e.target.value }))}
                      className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-2.5 pr-12 text-foreground outline-none focus:border-primary/60 text-sm"
                    />
                    <span className="absolute right-3 top-1/2 -translate-y-1/2 text-xs text-muted-foreground">{unit}</span>
                  </div>
                </div>
              ))}
            </div>
          </motion.div>
        )}

        {isLoading ? (
          <div className="grid md:grid-cols-3 gap-5 mb-8">
            {[1,2,3].map(i => (
              <div key={i} className="glass-card rounded-2xl p-5 h-40 animate-pulse border border-white/5" />
            ))}
          </div>
        ) : goals ? (
          <div className="grid md:grid-cols-3 gap-5 mb-8">
            <MacroCard
              icon={Flame}
              label="Calories"
              consumed={goals.consumed?.calories ?? 0}
              target={goals.calorieTarget}
              unit="kcal"
              color="#D6B36A"
            />
            <MacroCard
              icon={Dumbbell}
              label="Protein"
              consumed={goals.consumed?.protein ?? 0}
              target={goals.proteinTarget}
              unit="g"
              color="#60a5fa"
            />
            <MacroCard
              icon={Droplets}
              label="Fat"
              consumed={goals.consumed?.fat ?? 0}
              target={goals.fatTarget}
              unit="g"
              color="#f87171"
            />
          </div>
        ) : null}

        {/* Bottom row — deadline + forecast */}
        <div className="grid md:grid-cols-2 gap-5">
          {/* Deadline */}
          {daysLeft !== null && daysLeft !== undefined && (
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.3 }}
              className="glass-card rounded-2xl p-6 border border-white/8"
            >
              <div className="flex items-center gap-2 mb-4">
                <div className="w-8 h-8 rounded-lg bg-primary/10 flex items-center justify-center">
                  <Calendar size={15} className="text-gold" />
                </div>
                <h3 className="font-medium text-foreground">Deadline countdown</h3>
              </div>
              <div className="flex items-baseline gap-2">
                <span className="font-serif text-6xl text-gold">{daysLeft}</span>
                <span className="text-muted-foreground">days remaining</span>
              </div>
              <p className="text-xs text-muted-foreground mt-2">Stay consistent to hit your goal on time</p>
              <div className="mt-4 h-1 bg-white/5 rounded-full overflow-hidden">
                <div className="h-full bg-primary/60 rounded-full" style={{ width: `${Math.max(5, 100 - (daysLeft / 90) * 100)}%` }} />
              </div>
            </motion.div>
          )}

          {/* Forecast */}
          {forecast && (
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.35 }}
              className="glass-card rounded-2xl p-6 border border-white/8"
            >
              <div className="flex items-center gap-2 mb-4">
                <div className="w-8 h-8 rounded-lg bg-primary/10 flex items-center justify-center">
                  <TrendingUp size={15} className="text-gold" />
                </div>
                <h3 className="font-medium text-foreground">AI Forecast</h3>
              </div>
              <div className="flex items-center gap-2 mb-3">
                <span className="text-sm font-medium capitalize" style={{ color: trendColor }}>{forecast.trend}</span>
                <span className="text-xs text-muted-foreground">trajectory</span>
              </div>
              {forecast.goalCompletionDate && (
                <p className="text-sm text-muted-foreground mb-2">
                  Projected completion: <span className="text-foreground font-medium">{new Date(forecast.goalCompletionDate).toLocaleDateString()}</span>
                </p>
              )}
              <p className="text-xs text-muted-foreground leading-relaxed">{forecast.recommendation}</p>
            </motion.div>
          )}
        </div>
      </div>
      <VoiceAssistant />
    </div>
  );
}
