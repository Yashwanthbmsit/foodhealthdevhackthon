import { motion } from "framer-motion";
import { Bell, Droplets, Target, Trophy, Zap, Utensils, Check } from "lucide-react";
import { useGetNotifications, useMarkNotificationRead, getGetNotificationsQueryKey } from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { Navbar } from "@/components/Navbar";
import { VoiceAssistant } from "@/components/VoiceAssistant";

const typeConfig: Record<string, { icon: any; color: string; bg: string }> = {
  meal_reminder: { icon: Utensils, color: "#D6B36A", bg: "rgba(214,179,106,0.1)" },
  water_reminder: { icon: Droplets, color: "#60a5fa", bg: "rgba(96,165,250,0.1)" },
  goal_alert: { icon: Target, color: "#f87171", bg: "rgba(248,113,113,0.1)" },
  achievement: { icon: Trophy, color: "#4ade80", bg: "rgba(74,222,128,0.1)" },
  ai_insight: { icon: Zap, color: "#a78bfa", bg: "rgba(167,139,250,0.1)" },
};

function timeAgo(isoStr: string) {
  const diff = Date.now() - new Date(isoStr).getTime();
  const mins = Math.floor(diff / 60000);
  if (mins < 60) return `${mins}m ago`;
  const hrs = Math.floor(mins / 60);
  if (hrs < 24) return `${hrs}h ago`;
  return `${Math.floor(hrs / 24)}d ago`;
}

export default function NotificationsPage() {
  const { data: notifications, isLoading } = useGetNotifications();
  const markRead = useMarkNotificationRead();
  const queryClient = useQueryClient();

  const handleMarkRead = (id: number) => {
    markRead.mutate({ id }, {
      onSuccess: () => {
        queryClient.invalidateQueries({ queryKey: getGetNotificationsQueryKey() });
      }
    });
  };

  const unread = notifications?.filter(n => !n.read) ?? [];
  const read = notifications?.filter(n => n.read) ?? [];

  return (
    <div className="min-h-screen ambient-bg">
      <Navbar />
      <div className="pt-20 pb-16 max-w-2xl mx-auto px-6">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-10"
        >
          <div className="flex items-center gap-3 mb-2">
            <Bell size={20} className="text-gold" />
            <p className="text-xs text-muted-foreground uppercase tracking-widest">Notifications</p>
          </div>
          <h1 className="font-serif text-5xl text-foreground">
            <span className="text-gold">Alerts</span> &amp; updates
          </h1>
        </motion.div>

        {isLoading ? (
          <div className="space-y-3">
            {[1,2,3].map(i => (
              <div key={i} className="glass-card rounded-2xl p-4 h-20 animate-pulse border border-white/5" />
            ))}
          </div>
        ) : (
          <>
            {unread.length > 0 && (
              <div className="mb-6">
                <div className="flex items-center justify-between mb-3">
                  <p className="text-xs text-muted-foreground uppercase tracking-widest">New</p>
                  <span className="text-xs text-gold bg-primary/10 px-2 py-0.5 rounded-full border border-primary/20">
                    {unread.length} unread
                  </span>
                </div>
                <div className="space-y-2">
                  {unread.map((n, i) => {
                    const cfg = typeConfig[n.type] ?? typeConfig.ai_insight;
                    const Icon = cfg.icon;
                    return (
                      <motion.div
                        key={n.id}
                        data-testid={`notification-${n.id}`}
                        initial={{ opacity: 0, x: -15 }}
                        animate={{ opacity: 1, x: 0 }}
                        transition={{ delay: i * 0.06 }}
                        className="glass-card rounded-xl p-4 border border-white/10 flex items-start gap-3 group hover:border-white/15 transition-all"
                        style={{ borderLeft: `2px solid ${cfg.color}40` }}
                      >
                        <div className="w-9 h-9 rounded-xl flex items-center justify-center flex-shrink-0" style={{ backgroundColor: cfg.bg }}>
                          <Icon size={16} style={{ color: cfg.color }} />
                        </div>
                        <div className="flex-1 min-w-0">
                          <div className="flex items-start justify-between gap-2">
                            <p className="text-sm font-medium text-foreground">{n.title}</p>
                            <span className="text-xs text-muted-foreground flex-shrink-0">{timeAgo(n.createdAt)}</span>
                          </div>
                          <p className="text-xs text-muted-foreground mt-0.5 leading-relaxed">{n.message}</p>
                        </div>
                        <motion.button
                          data-testid={`btn-mark-read-${n.id}`}
                          onClick={() => handleMarkRead(n.id)}
                          className="w-7 h-7 rounded-lg bg-white/5 hover:bg-primary/20 flex items-center justify-center flex-shrink-0 opacity-0 group-hover:opacity-100 transition-all"
                          whileTap={{ scale: 0.9 }}
                        >
                          <Check size={12} className="text-gold" />
                        </motion.button>
                      </motion.div>
                    );
                  })}
                </div>
              </div>
            )}

            {read.length > 0 && (
              <div>
                <p className="text-xs text-muted-foreground uppercase tracking-widest mb-3">Earlier</p>
                <div className="space-y-2">
                  {read.map((n, i) => {
                    const cfg = typeConfig[n.type] ?? typeConfig.ai_insight;
                    const Icon = cfg.icon;
                    return (
                      <motion.div
                        key={n.id}
                        initial={{ opacity: 0 }}
                        animate={{ opacity: 1 }}
                        transition={{ delay: i * 0.04 }}
                        className="glass-card rounded-xl p-4 border border-white/6 flex items-start gap-3 opacity-60 hover:opacity-80 transition-all"
                      >
                        <div className="w-9 h-9 rounded-xl flex items-center justify-center flex-shrink-0" style={{ backgroundColor: `${cfg.bg}50` }}>
                          <Icon size={16} style={{ color: `${cfg.color}80` }} />
                        </div>
                        <div className="flex-1 min-w-0">
                          <div className="flex items-start justify-between gap-2">
                            <p className="text-sm text-muted-foreground">{n.title}</p>
                            <span className="text-xs text-muted-foreground/60 flex-shrink-0">{timeAgo(n.createdAt)}</span>
                          </div>
                          <p className="text-xs text-muted-foreground/60 mt-0.5">{n.message}</p>
                        </div>
                      </motion.div>
                    );
                  })}
                </div>
              </div>
            )}

            {(!notifications || notifications.length === 0) && (
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                className="text-center py-16"
              >
                <div className="w-16 h-16 rounded-full bg-white/5 border border-white/10 flex items-center justify-center mx-auto mb-4">
                  <Bell size={24} className="text-muted-foreground" />
                </div>
                <p className="text-muted-foreground text-sm">No notifications yet</p>
              </motion.div>
            )}
          </>
        )}
      </div>
      <VoiceAssistant />
    </div>
  );
}
