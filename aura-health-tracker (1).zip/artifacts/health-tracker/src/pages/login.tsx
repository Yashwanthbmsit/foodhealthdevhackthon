import { useState } from "react";
import { Link, useLocation } from "wouter";
import { motion } from "framer-motion";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Eye, EyeOff, ArrowRight } from "lucide-react";
import { useLogin } from "@workspace/api-client-react";
import { useAuth } from "@/contexts/AuthContext";
import { useToast } from "@/hooks/use-toast";

const schema = z.object({
  email: z.string().email("Enter a valid email"),
  password: z.string().min(6, "Password must be at least 6 characters"),
});
type FormData = z.infer<typeof schema>;

export default function LoginPage() {
  const [showPassword, setShowPassword] = useState(false);
  const { login } = useAuth();
  const [, setLocation] = useLocation();
  const loginMutation = useLogin();
  const { toast } = useToast();

  const form = useForm<FormData>({ resolver: zodResolver(schema) });

  const onSubmit = form.handleSubmit(data => {
    loginMutation.mutate({ data }, {
      onSuccess: (res) => {
        login(res.token, res.user);
      },
      onError: () => {
        toast({ title: "Login failed", description: "Invalid email or password.", variant: "destructive" });
      }
    });
  });

  return (
    <div className="min-h-screen flex">
      {/* Left panel — editorial */}
      <div className="hidden lg:flex flex-col justify-between w-1/2 p-12 relative overflow-hidden"
        style={{ background: "linear-gradient(135deg, #0a0a0a 0%, #0f0f10 100%)" }}>

        {/* Ambient glow */}
        <div className="absolute top-0 left-0 w-96 h-96 rounded-full opacity-20"
          style={{ background: "radial-gradient(circle, rgba(214,179,106,0.3), transparent)", transform: "translate(-30%, -30%)" }} />
        <div className="absolute bottom-0 right-0 w-96 h-96 rounded-full opacity-10"
          style={{ background: "radial-gradient(circle, rgba(214,179,106,0.2), transparent)", transform: "translate(30%, 30%)" }} />

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
        >
          <div className="flex items-center gap-2 mb-2">
            <div className="w-6 h-6 rounded-full border border-primary/40 bg-primary/10 flex items-center justify-center">
              <div className="w-2 h-2 rounded-full bg-primary" />
            </div>
            <span className="font-serif text-gold text-sm tracking-widest uppercase">Aura</span>
          </div>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3, duration: 0.8 }}
          className="z-10"
        >
          <h1 className="font-serif text-6xl leading-[1.05] tracking-tight text-foreground mb-6">
            Intelligence<br />
            <span className="text-gold">meets</span><br />
            nutrition.
          </h1>
          <p className="text-muted-foreground text-lg max-w-sm leading-relaxed">
            AI-powered health tracking designed for those who demand precision and elegance in every decision.
          </p>
        </motion.div>

        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.6 }}
          className="flex items-center gap-3 z-10"
        >
          {["2,400+ users", "AI-powered", "Real-time insights"].map((tag) => (
            <div key={tag} className="px-3 py-1.5 rounded-full border border-white/10 text-xs text-muted-foreground">
              {tag}
            </div>
          ))}
        </motion.div>
      </div>

      {/* Right panel — form */}
      <div className="flex-1 flex items-center justify-center p-8 bg-background">
        <motion.div
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.6, ease: [0.16, 1, 0.3, 1] }}
          className="w-full max-w-md"
        >
          <div className="mb-10">
            <h2 className="font-serif text-3xl text-foreground mb-2">Welcome back</h2>
            <p className="text-muted-foreground">Sign in to your Aura account</p>
          </div>

          <form onSubmit={onSubmit} className="space-y-5">
            <div>
              <label className="block text-sm text-muted-foreground mb-2">Email</label>
              <input
                data-testid="input-email"
                type="email"
                {...form.register("email")}
                placeholder="your@email.com"
                className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 text-foreground placeholder:text-muted-foreground outline-none focus:border-primary/60 transition-all text-sm"
              />
              {form.formState.errors.email && (
                <p className="text-destructive text-xs mt-1">{form.formState.errors.email.message}</p>
              )}
            </div>

            <div>
              <label className="block text-sm text-muted-foreground mb-2">Password</label>
              <div className="relative">
                <input
                  data-testid="input-password"
                  type={showPassword ? "text" : "password"}
                  {...form.register("password")}
                  placeholder="••••••••"
                  className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 pr-12 text-foreground placeholder:text-muted-foreground outline-none focus:border-primary/60 transition-all text-sm"
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground transition-colors"
                >
                  {showPassword ? <EyeOff size={16} /> : <Eye size={16} />}
                </button>
              </div>
              {form.formState.errors.password && (
                <p className="text-destructive text-xs mt-1">{form.formState.errors.password.message}</p>
              )}
            </div>

            <motion.button
              data-testid="btn-login"
              type="submit"
              disabled={loginMutation.isPending}
              className="w-full flex items-center justify-center gap-2 py-3.5 rounded-xl font-medium text-sm transition-all disabled:opacity-70"
              style={{ background: "linear-gradient(135deg, #D6B36A, #a8853f)" }}
              whileHover={{ scale: 1.01, boxShadow: "0 0 25px rgba(214,179,106,0.3)" }}
              whileTap={{ scale: 0.99 }}
            >
              {loginMutation.isPending ? (
                <div className="w-4 h-4 border-2 border-black/30 border-t-black rounded-full animate-spin" />
              ) : (
                <>
                  <span className="text-black font-semibold">Sign in</span>
                  <ArrowRight size={16} className="text-black" />
                </>
              )}
            </motion.button>
          </form>

          <p className="mt-8 text-center text-sm text-muted-foreground">
            New to Aura?{" "}
            <Link href="/signup">
              <span className="text-gold hover:underline cursor-pointer">Create an account</span>
            </Link>
          </p>
        </motion.div>
      </div>
    </div>
  );
}
