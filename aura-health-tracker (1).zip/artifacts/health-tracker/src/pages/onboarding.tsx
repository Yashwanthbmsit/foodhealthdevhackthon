import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { ArrowRight, ArrowLeft, Check } from "lucide-react";
import { useCompleteOnboarding, getGetCurrentUserQueryKey } from "@workspace/api-client-react";
import { useAuth } from "@/contexts/AuthContext";
import { useLocation } from "wouter";
import { useToast } from "@/hooks/use-toast";
import { useQueryClient } from "@tanstack/react-query";

const steps = [
  {
    id: "ageGroup",
    title: "How old are you?",
    subtitle: "We'll tailor your nutrition goals to your age group",
    options: [
      { value: "18-25", label: "18 – 25" },
      { value: "26-35", label: "26 – 35" },
      { value: "36-45", label: "36 – 45" },
      { value: "46-55", label: "46 – 55" },
      { value: "55+", label: "55 +" },
    ],
  },
  {
    id: "diet",
    title: "Your diet style",
    subtitle: "Select the eating pattern that best describes you",
    options: [
      { value: "omnivore", label: "Omnivore" },
      { value: "vegetarian", label: "Vegetarian" },
      { value: "vegan", label: "Vegan" },
      { value: "keto", label: "Ketogenic" },
      { value: "paleo", label: "Paleo" },
      { value: "mediterranean", label: "Mediterranean" },
    ],
  },
  {
    id: "goal",
    title: "Your primary goal",
    subtitle: "What are you working towards?",
    options: [
      { value: "lose_weight", label: "Lose Weight" },
      { value: "gain_muscle", label: "Gain Muscle" },
      { value: "maintain_weight", label: "Maintain Weight" },
      { value: "improve_energy", label: "Improve Energy" },
      { value: "better_nutrition", label: "Better Nutrition" },
    ],
  },
];

export default function OnboardingPage() {
  const [step, setStep] = useState(0);
  const [answers, setAnswers] = useState<Record<string, string>>({});
  const [deadline, setDeadline] = useState("");
  const [, setLocation] = useLocation();
  const { user } = useAuth();
  const queryClient = useQueryClient();
  const completeOnboarding = useCompleteOnboarding();
  const { toast } = useToast();

  const currentStep = steps[step];
  const isLastDataStep = step === steps.length - 1;
  const isDeadlineStep = step === steps.length;
  const progress = ((step) / (steps.length + 1)) * 100;

  const handleSelect = (value: string) => {
    setAnswers(prev => ({ ...prev, [currentStep.id]: value }));
  };

  const handleNext = () => {
    if (isDeadlineStep) {
      handleSubmit();
    } else {
      setStep(s => s + 1);
    }
  };

  const handleSubmit = () => {
    const payload = {
      ageGroup: answers.ageGroup as any,
      diet: answers.diet as any,
      goal: answers.goal as any,
      goalDeadline: deadline || new Date(Date.now() + 90 * 24 * 60 * 60 * 1000).toISOString().split("T")[0],
    };

    completeOnboarding.mutate({ data: payload }, {
      onSuccess: () => {
        // Update the cached user so ProtectedRoute sees onboardingComplete: true
        queryClient.setQueryData(getGetCurrentUserQueryKey(), (old: any) => ({
          ...(old ?? {}),
          onboardingComplete: true,
        }));
        setLocation("/dashboard");
      },
      onError: () => {
        toast({ title: "Error", description: "Failed to save your preferences.", variant: "destructive" });
      }
    });
  };

  const canProceed = isDeadlineStep ? true : !!answers[currentStep?.id];

  return (
    <div className="min-h-screen ambient-bg flex flex-col items-center justify-center px-6 py-12 relative">
      {/* Ambient blobs */}
      <div className="fixed top-0 left-1/2 -translate-x-1/2 w-[600px] h-[300px] rounded-full opacity-10 blur-3xl pointer-events-none"
        style={{ background: "radial-gradient(ellipse, rgba(214,179,106,0.5), transparent)" }} />

      {/* Logo */}
      <motion.div
        initial={{ opacity: 0, y: -10 }}
        animate={{ opacity: 1, y: 0 }}
        className="absolute top-8 left-8 flex items-center gap-2"
      >
        <div className="w-6 h-6 rounded-full border border-primary/40 bg-primary/10 flex items-center justify-center">
          <div className="w-2 h-2 rounded-full bg-primary" />
        </div>
        <span className="font-serif text-gold text-sm tracking-widest uppercase">Aura</span>
      </motion.div>

      {/* Progress */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        className="w-full max-w-lg mb-10"
      >
        <div className="flex justify-between text-xs text-muted-foreground mb-2">
          <span>Setting up your profile</span>
          <span>{step + 1} / {steps.length + 1}</span>
        </div>
        <div className="h-0.5 bg-white/5 rounded-full overflow-hidden">
          <motion.div
            className="h-full bg-primary rounded-full"
            animate={{ width: `${progress}%` }}
            transition={{ duration: 0.5, ease: "easeOut" }}
          />
        </div>
      </motion.div>

      {/* Content */}
      <div className="w-full max-w-lg">
        <AnimatePresence mode="wait">
          {!isDeadlineStep ? (
            <motion.div
              key={`step-${step}`}
              initial={{ opacity: 0, x: 30 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -30 }}
              transition={{ duration: 0.35, ease: [0.16, 1, 0.3, 1] }}
            >
              <h2 className="font-serif text-4xl text-foreground mb-2">{currentStep.title}</h2>
              <p className="text-muted-foreground mb-8">{currentStep.subtitle}</p>

              <div className="grid grid-cols-2 gap-3">
                {currentStep.options.map((opt) => {
                  const selected = answers[currentStep.id] === opt.value;
                  return (
                    <motion.button
                      key={opt.value}
                      data-testid={`option-${opt.value}`}
                      onClick={() => handleSelect(opt.value)}
                      className={`relative p-4 rounded-xl text-left border transition-all duration-200 ${
                        selected
                          ? "border-primary/60 bg-primary/10 gold-glow-sm"
                          : "border-white/10 bg-white/3 hover:border-white/20 hover:bg-white/5"
                      }`}
                      whileHover={{ scale: 1.02 }}
                      whileTap={{ scale: 0.98 }}
                    >
                      {selected && (
                        <motion.div
                          initial={{ scale: 0 }}
                          animate={{ scale: 1 }}
                          className="absolute top-3 right-3 w-5 h-5 rounded-full bg-primary flex items-center justify-center"
                        >
                          <Check size={11} className="text-black" />
                        </motion.div>
                      )}
                      <span className={`font-medium text-sm ${selected ? "text-gold" : "text-foreground"}`}>
                        {opt.label}
                      </span>
                    </motion.button>
                  );
                })}
              </div>
            </motion.div>
          ) : (
            <motion.div
              key="deadline"
              initial={{ opacity: 0, x: 30 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -30 }}
              transition={{ duration: 0.35, ease: [0.16, 1, 0.3, 1] }}
            >
              <h2 className="font-serif text-4xl text-foreground mb-2">Set your deadline</h2>
              <p className="text-muted-foreground mb-8">When do you want to achieve your goal?</p>

              <div className="glass-card rounded-2xl p-6 mb-6">
                <label className="block text-sm text-muted-foreground mb-3">Target date</label>
                <input
                  data-testid="input-deadline"
                  type="date"
                  value={deadline}
                  onChange={e => setDeadline(e.target.value)}
                  min={new Date().toISOString().split("T")[0]}
                  className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 text-foreground outline-none focus:border-primary/60 transition-all text-sm"
                />
                <p className="text-xs text-muted-foreground mt-3">
                  Leave empty to use a 90-day default target
                </p>
              </div>

              <div className="glass-card rounded-2xl p-4 border border-primary/20">
                <h4 className="text-sm font-medium text-gold mb-3">Your profile summary</h4>
                <div className="grid grid-cols-3 gap-3">
                  {[
                    { label: "Age group", value: answers.ageGroup },
                    { label: "Diet", value: answers.diet },
                    { label: "Goal", value: answers.goal?.replace(/_/g, " ") },
                  ].map(item => (
                    <div key={item.label} className="text-center">
                      <p className="text-xs text-muted-foreground mb-1">{item.label}</p>
                      <p className="text-sm text-foreground font-medium capitalize">{item.value}</p>
                    </div>
                  ))}
                </div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Navigation */}
        <div className="flex items-center justify-between mt-8">
          <motion.button
            onClick={() => setStep(s => Math.max(0, s - 1))}
            disabled={step === 0}
            className="flex items-center gap-2 px-5 py-2.5 rounded-xl border border-white/10 text-muted-foreground hover:text-foreground hover:border-white/20 transition-all disabled:opacity-30 disabled:cursor-not-allowed text-sm"
            whileHover={{ scale: 1.02 }}
            whileTap={{ scale: 0.98 }}
          >
            <ArrowLeft size={15} />
            Back
          </motion.button>

          <motion.button
            data-testid="btn-next-step"
            onClick={handleNext}
            disabled={!canProceed || completeOnboarding.isPending}
            className="flex items-center gap-2 px-6 py-2.5 rounded-xl text-black font-semibold text-sm disabled:opacity-40 disabled:cursor-not-allowed transition-all"
            style={{ background: canProceed ? "linear-gradient(135deg, #D6B36A, #a8853f)" : undefined, backgroundColor: canProceed ? undefined : "rgba(255,255,255,0.1)" }}
            whileHover={canProceed ? { scale: 1.03, boxShadow: "0 0 20px rgba(214,179,106,0.3)" } : {}}
            whileTap={{ scale: 0.97 }}
          >
            {completeOnboarding.isPending ? (
              <div className="w-4 h-4 border-2 border-black/30 border-t-black rounded-full animate-spin" />
            ) : (
              <>
                {isDeadlineStep ? "Complete Setup" : "Continue"}
                <ArrowRight size={15} />
              </>
            )}
          </motion.button>
        </div>
      </div>
    </div>
  );
}
