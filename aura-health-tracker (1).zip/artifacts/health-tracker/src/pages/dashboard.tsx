import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Plus, Scan, ChevronDown, ChevronUp, Trash2, Sunrise, Sun, Sunset, Moon, Zap } from "lucide-react";
import {
  useGetMeals, useGetDailySummary, useCreateMeal, useDeleteMeal,
  useGetRecommendations, getGetMealsQueryKey, getGetDailySummaryQueryKey,
} from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { Navbar } from "@/components/Navbar";
import { VoiceAssistant } from "@/components/VoiceAssistant";
import { useAuth } from "@/contexts/AuthContext";
import { Link } from "wouter";
import { useToast } from "@/hooks/use-toast";

const TODAY = new Date().toISOString().split("T")[0];

type Period = "morning" | "afternoon" | "evening" | "night";
const PERIODS: { id: Period; label: string; icon: any; timeHint: string }[] = [
  { id: "morning", label: "Morning", icon: Sunrise, timeHint: "6am – 12pm" },
  { id: "afternoon", label: "Afternoon", icon: Sun, timeHint: "12pm – 5pm" },
  { id: "evening", label: "Evening", icon: Sunset, timeHint: "5pm – 9pm" },
  { id: "night", label: "Night", icon: Moon, timeHint: "9pm – 6am" },
];

function AddFoodForm({ period, onClose }: { period: Period; onClose: () => void }) {
  const [form, setForm] = useState({ name: "", calories: "", protein: "", fat: "", carbs: "" });
  const createMeal = useCreateMeal();
  const queryClient = useQueryClient();
  const { toast } = useToast();

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.name || !form.calories) return;
    createMeal.mutate({
      data: {
        name: form.name,
        calories: Number(form.calories),
        protein: Number(form.protein) || 0,
        fat: Number(form.fat) || 0,
        carbs: Number(form.carbs) || 0,
        period,
        date: TODAY,
      }
    }, {
      onSuccess: () => {
        queryClient.invalidateQueries({ queryKey: getGetMealsQueryKey({ date: TODAY, period }) });
        queryClient.invalidateQueries({ queryKey: getGetDailySummaryQueryKey({ date: TODAY }) });
        onClose();
        toast({ title: "Food added", description: `${form.name} added to ${period}` });
      }
    });
  };

  return (
    <motion.form
      initial={{ opacity: 0, height: 0 }}
      animate={{ opacity: 1, height: "auto" }}
      exit={{ opacity: 0, height: 0 }}
      onSubmit={handleSubmit}
      className="overflow-hidden"
    >
      <div className="pt-3 border-t border-white/8 mt-3">
        <div className="grid grid-cols-2 gap-2 mb-2">
          <input
            data-testid="input-food-name"
            placeholder="Food name"
            value={form.name}
            onChange={e => setForm(f => ({ ...f, name: e.target.value }))}
            className="bg-white/5 border border-white/10 rounded-lg px-3 py-2 text-sm text-foreground placeholder:text-muted-foreground outline-none focus:border-primary/50 col-span-2"
          />
          <input
            data-testid="input-food-calories"
            placeholder="Calories"
            type="number"
            value={form.calories}
            onChange={e => setForm(f => ({ ...f, calories: e.target.value }))}
            className="bg-white/5 border border-white/10 rounded-lg px-3 py-2 text-sm text-foreground placeholder:text-muted-foreground outline-none focus:border-primary/50"
          />
          <input
            placeholder="Protein (g)"
            type="number"
            value={form.protein}
            onChange={e => setForm(f => ({ ...f, protein: e.target.value }))}
            className="bg-white/5 border border-white/10 rounded-lg px-3 py-2 text-sm text-foreground placeholder:text-muted-foreground outline-none focus:border-primary/50"
          />
          <input
            placeholder="Fat (g)"
            type="number"
            value={form.fat}
            onChange={e => setForm(f => ({ ...f, fat: e.target.value }))}
            className="bg-white/5 border border-white/10 rounded-lg px-3 py-2 text-sm text-foreground placeholder:text-muted-foreground outline-none focus:border-primary/50"
          />
          <input
            placeholder="Carbs (g)"
            type="number"
            value={form.carbs}
            onChange={e => setForm(f => ({ ...f, carbs: e.target.value }))}
            className="bg-white/5 border border-white/10 rounded-lg px-3 py-2 text-sm text-foreground placeholder:text-muted-foreground outline-none focus:border-primary/50"
          />
        </div>
        <div className="flex gap-2">
          <button
            type="button"
            onClick={onClose}
            className="flex-1 py-2 rounded-lg border border-white/10 text-muted-foreground text-xs hover:text-foreground transition-all"
          >
            Cancel
          </button>
          <motion.button
            data-testid="btn-submit-food"
            type="submit"
            disabled={createMeal.isPending}
            className="flex-1 py-2 rounded-lg text-black text-xs font-semibold disabled:opacity-50"
            style={{ background: "linear-gradient(135deg, #D6B36A, #a8853f)" }}
            whileHover={{ scale: 1.02 }}
            whileTap={{ scale: 0.98 }}
          >
            {createMeal.isPending ? "Adding..." : "Add food"}
          </motion.button>
        </div>
      </div>
    </motion.form>
  );
}

function PeriodSection({ period }: { period: typeof PERIODS[number] }) {
  const [open, setOpen] = useState(true);
  const [showForm, setShowForm] = useState(false);
  const { data: meals } = useGetMeals({ date: TODAY, period: period.id }, {
    query: { queryKey: getGetMealsQueryKey({ date: TODAY, period: period.id }) }
  });
  const deleteMeal = useDeleteMeal();
  const queryClient = useQueryClient();
  const Icon = period.icon;

  const totalCals = meals?.reduce((s, m) => s + m.calories, 0) ?? 0;
  const totalProtein = meals?.reduce((s, m) => s + m.protein, 0) ?? 0;
  const totalFat = meals?.reduce((s, m) => s + m.fat, 0) ?? 0;

  const handleDelete = (id: number) => {
    deleteMeal.mutate({ id }, {
      onSuccess: () => {
        queryClient.invalidateQueries({ queryKey: getGetMealsQueryKey({ date: TODAY, period: period.id }) });
        queryClient.invalidateQueries({ queryKey: getGetDailySummaryQueryKey({ date: TODAY }) });
      }
    });
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 15 }}
      animate={{ opacity: 1, y: 0 }}
      className="glass-card rounded-2xl border border-white/8 overflow-hidden"
    >
      {/* Header */}
      <div
        className="flex items-center justify-between p-4 cursor-pointer hover:bg-white/3 transition-all"
        onClick={() => setOpen(o => !o)}
      >
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 rounded-xl bg-primary/10 flex items-center justify-center">
            <Icon size={16} className="text-gold" />
          </div>
          <div>
            <h3 className="font-medium text-foreground text-sm">{period.label}</h3>
            <p className="text-xs text-muted-foreground">{period.timeHint}</p>
          </div>
        </div>
        <div className="flex items-center gap-4">
          {totalCals > 0 && (
            <div className="text-right hidden sm:block">
              <p className="text-sm font-semibold text-gold">{Math.round(totalCals)} <span className="text-xs text-muted-foreground font-normal">kcal</span></p>
              <p className="text-xs text-muted-foreground">{Math.round(totalProtein)}g P · {Math.round(totalFat)}g F</p>
            </div>
          )}
          {meals && meals.length > 0 && (
            <span className="text-xs text-muted-foreground bg-white/5 px-2 py-0.5 rounded-full">
              {meals.length} item{meals.length !== 1 ? "s" : ""}
            </span>
          )}
          {open ? <ChevronUp size={15} className="text-muted-foreground" /> : <ChevronDown size={15} className="text-muted-foreground" />}
        </div>
      </div>

      {/* Body */}
      <AnimatePresence>
        {open && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: "auto", opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            transition={{ duration: 0.25 }}
            className="overflow-hidden"
          >
            <div className="px-4 pb-4 border-t border-white/6">
              {/* Meal list */}
              {meals && meals.length > 0 ? (
                <div className="mt-3 space-y-2 mb-3">
                  {meals.map(meal => (
                    <motion.div
                      key={meal.id}
                      data-testid={`meal-item-${meal.id}`}
                      initial={{ opacity: 0, x: -8 }}
                      animate={{ opacity: 1, x: 0 }}
                      className="flex items-center justify-between py-2 group"
                    >
                      <div className="flex items-center gap-2 flex-1 min-w-0">
                        <div className="w-1.5 h-1.5 rounded-full bg-primary/50 flex-shrink-0" />
                        <span className="text-sm text-foreground truncate">{meal.name}</span>
                      </div>
                      <div className="flex items-center gap-3 flex-shrink-0 ml-2">
                        <div className="text-right hidden sm:block">
                          <span className="text-xs text-gold font-medium">{Math.round(meal.calories)}</span>
                          <span className="text-xs text-muted-foreground"> kcal</span>
                        </div>
                        <span className="text-xs text-muted-foreground hidden md:block">{Math.round(meal.protein)}g P</span>
                        <button
                          data-testid={`btn-delete-meal-${meal.id}`}
                          onClick={() => handleDelete(meal.id)}
                          className="opacity-0 group-hover:opacity-100 text-muted-foreground hover:text-destructive transition-all p-1"
                        >
                          <Trash2 size={13} />
                        </button>
                      </div>
                    </motion.div>
                  ))}
                </div>
              ) : (
                <p className="text-xs text-muted-foreground mt-3 mb-3">No food logged for {period.label.toLowerCase()}</p>
              )}

              {/* Add food form */}
              <AnimatePresence>
                {showForm && (
                  <AddFoodForm period={period.id} onClose={() => setShowForm(false)} />
                )}
              </AnimatePresence>

              {/* Actions */}
              {!showForm && (
                <div className="flex gap-2 mt-2">
                  <motion.button
                    data-testid={`btn-add-food-${period.id}`}
                    onClick={() => setShowForm(true)}
                    className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-white/10 text-muted-foreground hover:text-foreground hover:border-white/20 text-xs transition-all"
                    whileHover={{ scale: 1.02 }}
                    whileTap={{ scale: 0.98 }}
                  >
                    <Plus size={13} />
                    Add food
                  </motion.button>
                  <Link href="/analysis">
                    <motion.div
                      data-testid={`btn-scan-food-${period.id}`}
                      className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-primary/25 text-gold text-xs hover:bg-primary/10 transition-all cursor-pointer"
                      whileHover={{ scale: 1.02 }}
                      whileTap={{ scale: 0.98 }}
                    >
                      <Scan size={13} />
                      Scan food
                    </motion.div>
                  </Link>
                </div>
              )}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </motion.div>
  );
}

export default function DashboardPage() {
  const { user } = useAuth();
  const { data: summary } = useGetDailySummary({ date: TODAY }, {
    query: { queryKey: getGetDailySummaryQueryKey({ date: TODAY }) }
  });
  const { data: recommendations } = useGetRecommendations();

  const greeting = () => {
    const h = new Date().getHours();
    if (h < 12) return "Good morning";
    if (h < 18) return "Good afternoon";
    if (h < 21) return "Good evening";
    return "Good night";
  };

  return (
    <div className="min-h-screen ambient-bg">
      <Navbar />
      <div className="pt-20 pb-16 max-w-5xl mx-auto px-6">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          className="mb-8"
        >
          <p className="text-muted-foreground text-sm mb-1">{greeting()},</p>
          <h1 className="font-serif text-5xl text-foreground">
            {user?.name?.split(" ")[0] ?? "Friend"}
          </h1>
          <p className="text-muted-foreground mt-2">
            {new Date().toLocaleDateString("en-US", { weekday: "long", month: "long", day: "numeric" })}
          </p>
        </motion.div>

        {/* Daily summary */}
        {summary && (
          <motion.div
            initial={{ opacity: 0, y: 15 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 }}
            className="glass-card rounded-2xl p-5 mb-6 border border-primary/15"
            style={{ background: "rgba(214,179,106,0.03)" }}
          >
            <p className="text-xs text-muted-foreground uppercase tracking-widest mb-4">Today's totals</p>
            <div className="grid grid-cols-4 gap-4">
              {[
                { label: "Calories", value: Math.round(summary.totalCalories), unit: "kcal", color: "#D6B36A" },
                { label: "Protein", value: Math.round(summary.totalProtein), unit: "g", color: "#60a5fa" },
                { label: "Fat", value: Math.round(summary.totalFat), unit: "g", color: "#f87171" },
                { label: "Carbs", value: Math.round(summary.totalCarbs), unit: "g", color: "#4ade80" },
              ].map(stat => (
                <div key={stat.label} className="text-center" data-testid={`summary-${stat.label.toLowerCase()}`}>
                  <div className="text-2xl font-semibold" style={{ color: stat.color }}>{stat.value}</div>
                  <div className="text-xs text-muted-foreground">{stat.unit}</div>
                  <div className="text-xs text-muted-foreground/70 mt-0.5">{stat.label}</div>
                </div>
              ))}
            </div>
          </motion.div>
        )}

        <div className="grid lg:grid-cols-3 gap-6">
          {/* Meal periods — main col */}
          <div className="lg:col-span-2 space-y-4">
            {PERIODS.map((period, i) => (
              <motion.div
                key={period.id}
                initial={{ opacity: 0, y: 15 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.15 + i * 0.08 }}
              >
                <PeriodSection period={period} />
              </motion.div>
            ))}
          </div>

          {/* Sidebar — recommendations */}
          <div className="space-y-4">
            <motion.div
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.3 }}
              className="glass-card rounded-2xl p-5 border border-white/8"
            >
              <div className="flex items-center gap-2 mb-4">
                <div className="w-7 h-7 rounded-lg bg-primary/10 flex items-center justify-center">
                  <Zap size={13} className="text-gold" />
                </div>
                <p className="text-sm font-medium text-foreground">AI Recommendations</p>
              </div>

              {recommendations ? (
                <div className="space-y-3">
                  {recommendations.slice(0, 4).map((rec, i) => (
                    <motion.div
                      key={rec.id}
                      data-testid={`recommendation-${rec.id}`}
                      initial={{ opacity: 0, x: 10 }}
                      animate={{ opacity: 1, x: 0 }}
                      transition={{ delay: 0.35 + i * 0.07 }}
                      className="flex items-start gap-2.5 p-3 rounded-xl bg-white/3 hover:bg-white/5 transition-all border border-white/5"
                    >
                      <div className={`w-2 h-2 rounded-full mt-1.5 flex-shrink-0 ${rec.priority === "high" ? "bg-red-400" : rec.priority === "medium" ? "bg-primary" : "bg-green-400"}`} />
                      <div>
                        <p className="text-xs font-medium text-foreground">{rec.title}</p>
                        <p className="text-xs text-muted-foreground mt-0.5">{rec.description}</p>
                      </div>
                    </motion.div>
                  ))}
                </div>
              ) : (
                <div className="space-y-2">
                  {[1,2,3].map(i => (
                    <div key={i} className="h-14 animate-pulse bg-white/3 rounded-xl border border-white/5" />
                  ))}
                </div>
              )}
            </motion.div>

            {/* Quick link to analytics */}
            <Link href="/analytics">
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ delay: 0.5 }}
                className="glass-card rounded-2xl p-4 border border-white/8 hover:border-primary/25 transition-all cursor-pointer group"
              >
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-xs text-muted-foreground">Weekly report</p>
                    <p className="text-sm text-foreground group-hover:text-gold transition-colors mt-0.5">View analytics</p>
                  </div>
                  <div className="w-8 h-8 rounded-lg bg-white/5 flex items-center justify-center">
                    <span className="text-muted-foreground group-hover:text-gold transition-colors text-sm">→</span>
                  </div>
                </div>
              </motion.div>
            </Link>
          </div>
        </div>
      </div>
      <VoiceAssistant />
    </div>
  );
}
