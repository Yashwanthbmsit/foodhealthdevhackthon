import { useState, useRef, useCallback, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Mic, MicOff, X, Send, Volume2, Loader2 } from "lucide-react";
import { useCreateMeal } from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";

const BARS = [2, 5, 8, 12, 8, 5, 3, 7, 11, 7, 4, 6, 10, 6, 3];
const PERIODS = ["morning", "afternoon", "evening", "night"] as const;

type Message = { role: "user" | "aura"; text: string };

async function processAudio(audioBase64: string, mimeType: string) {
  const token = localStorage.getItem("auth_token");
  const res = await fetch("/api/voice/process-audio", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      ...(token ? { Authorization: `Bearer ${token}` } : {}),
    },
    body: JSON.stringify({ audioBase64, mimeType }),
  });
  if (!res.ok) throw new Error("Voice processing failed");
  return res.json() as Promise<{
    transcript: string;
    response: string;
    intent: string;
    meal: any | null;
    audioBase64: string | null;
  }>;
}

async function processTextCommand(command: string) {
  const token = localStorage.getItem("auth_token");
  const res = await fetch("/api/voice/process-audio", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      ...(token ? { Authorization: `Bearer ${token}` } : {}),
    },
    body: JSON.stringify({ audioBase64: btoa(command), mimeType: "text/plain", isText: true }),
  });
  if (!res.ok) throw new Error("Voice processing failed");
  return res.json();
}

function playAudioBase64(base64: string) {
  try {
    const binary = atob(base64);
    const bytes = new Uint8Array(binary.length);
    for (let i = 0; i < binary.length; i++) bytes[i] = binary.charCodeAt(i);
    const blob = new Blob([bytes], { type: "audio/mp3" });
    const url = URL.createObjectURL(blob);
    const audio = new Audio(url);
    audio.onended = () => URL.revokeObjectURL(url);
    audio.play().catch(() => {});
  } catch {}
}

export function VoiceAssistant() {
  const [open, setOpen] = useState(false);
  const [text, setText] = useState("");
  const [messages, setMessages] = useState<Message[]>([]);
  const [pendingMeal, setPendingMeal] = useState<any | null>(null);
  const [selectedPeriod, setSelectedPeriod] = useState<typeof PERIODS[number]>("morning");
  const [loading, setLoading] = useState(false);
  const [recording, setRecording] = useState(false);
  const [speaking, setSpeaking] = useState(false);

  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const chunksRef = useRef<Blob[]>([]);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const queryClient = useQueryClient();
  const createMeal = useCreateMeal();
  const { toast } = useToast();

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  useEffect(() => {
    if (open && messages.length === 0) {
      setMessages([{ role: "aura", text: "Hi! I'm AURA. You can speak or type — try saying 'I ate 2 eggs for breakfast' or ask 'How am I doing today?'" }]);
    }
  }, [open]);

  const handleResponse = useCallback(async (result: Awaited<ReturnType<typeof processAudio>>) => {
    setMessages(prev => [...prev, { role: "aura", text: result.response }]);

    if (result.audioBase64) {
      setSpeaking(true);
      playAudioBase64(result.audioBase64);
      setTimeout(() => setSpeaking(false), 4000);
    }

    if (result.intent === "add_food" && result.meal) {
      setPendingMeal(result.meal);
      if (result.meal.period && PERIODS.includes(result.meal.period)) {
        setSelectedPeriod(result.meal.period);
      }
    }
  }, []);

  const startRecording = useCallback(async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      const mimeType = MediaRecorder.isTypeSupported("audio/webm;codecs=opus")
        ? "audio/webm;codecs=opus"
        : MediaRecorder.isTypeSupported("audio/webm")
        ? "audio/webm"
        : "audio/mp4";

      const recorder = new MediaRecorder(stream, { mimeType });
      chunksRef.current = [];

      recorder.ondataavailable = e => { if (e.data.size > 0) chunksRef.current.push(e.data); };

      recorder.onstop = async () => {
        stream.getTracks().forEach(t => t.stop());
        if (chunksRef.current.length === 0) return;

        const blob = new Blob(chunksRef.current, { type: mimeType });
        const reader = new FileReader();
        reader.onloadend = async () => {
          const base64 = (reader.result as string).split(",")[1];
          setLoading(true);
          try {
            const result = await processAudio(base64, mimeType);
            if (result.transcript) {
              setMessages(prev => [...prev, { role: "user", text: result.transcript }]);
            }
            await handleResponse(result);
          } catch {
            toast({ title: "Voice error", description: "Could not process your audio. Please try again.", variant: "destructive" });
          } finally {
            setLoading(false);
          }
        };
        reader.readAsDataURL(blob);
      };

      recorder.start();
      mediaRecorderRef.current = recorder;
      setRecording(true);
    } catch {
      toast({ title: "Microphone access denied", description: "Please allow microphone access to use voice input.", variant: "destructive" });
    }
  }, [handleResponse, toast]);

  const stopRecording = useCallback(() => {
    mediaRecorderRef.current?.stop();
    mediaRecorderRef.current = null;
    setRecording(false);
  }, []);

  const handleSendText = useCallback(async () => {
    const cmd = text.trim();
    if (!cmd || loading) return;
    setText("");
    setMessages(prev => [...prev, { role: "user", text: cmd }]);
    setLoading(true);
    try {
      const token = localStorage.getItem("auth_token");
      const res = await fetch("/api/voice/command", {
        method: "POST",
        headers: { "Content-Type": "application/json", ...(token ? { Authorization: `Bearer ${token}` } : {}) },
        body: JSON.stringify({ command: cmd }),
      });
      if (!res.ok) throw new Error("Failed");
      const data = await res.json();
      setMessages(prev => [...prev, { role: "aura", text: data.message }]);
      if (data.intent === "add_food" && data.meal) {
        setPendingMeal(data.meal);
        if (data.meal.period && PERIODS.includes(data.meal.period)) setSelectedPeriod(data.meal.period);
      }
    } catch {
      toast({ title: "Error", description: "Could not process command.", variant: "destructive" });
    } finally {
      setLoading(false);
    }
  }, [text, loading, toast]);

  const handleAddMeal = useCallback(() => {
    if (!pendingMeal) return;
    const today = new Date().toISOString().split("T")[0];
    createMeal.mutate({
      data: {
        name: pendingMeal.name,
        calories: pendingMeal.calories,
        protein: pendingMeal.protein,
        fat: pendingMeal.fat,
        carbs: pendingMeal.carbs,
        category: pendingMeal.category ?? "other",
        period: selectedPeriod,
        date: today,
      },
    }, {
      onSuccess: () => {
        queryClient.invalidateQueries({ queryKey: ["/api/meals"] });
        queryClient.invalidateQueries({ queryKey: ["/api/meals/summary"] });
        setMessages(prev => [...prev, { role: "aura", text: `${pendingMeal.name} added to your ${selectedPeriod} log!` }]);
        setPendingMeal(null);
      },
    });
  }, [pendingMeal, selectedPeriod, createMeal, queryClient]);

  const handleClose = () => {
    if (recording) stopRecording();
    setOpen(false);
  };

  return (
    <>
      {/* Floating orb */}
      <motion.button
        data-testid="voice-assistant-toggle"
        onClick={() => (open ? handleClose() : setOpen(true))}
        className="fixed bottom-8 right-8 z-50 w-14 h-14 rounded-full flex items-center justify-center"
        style={{
          background: recording
            ? "linear-gradient(135deg, #ef4444, #b91c1c)"
            : "linear-gradient(135deg, #D6B36A, #a8853f)",
          boxShadow: recording
            ? "0 0 30px rgba(239,68,68,0.5), 0 0 60px rgba(239,68,68,0.2)"
            : "0 0 30px rgba(214,179,106,0.4), 0 0 60px rgba(214,179,106,0.15)",
        }}
        whileHover={{ scale: 1.1 }}
        whileTap={{ scale: 0.9 }}
        animate={recording ? { scale: [1, 1.08, 1] } : {}}
        transition={recording ? { duration: 1, repeat: Infinity } : {}}
      >
        {open ? <X size={20} className="text-black" /> : <Mic size={20} className="text-black" />}
      </motion.button>

      <AnimatePresence>
        {open && (
          <motion.div
            initial={{ opacity: 0, y: 24, scale: 0.95 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 24, scale: 0.95 }}
            transition={{ duration: 0.25, ease: [0.16, 1, 0.3, 1] }}
            className="fixed bottom-28 right-8 z-50 w-88 flex flex-col glass-card rounded-2xl border border-white/10 overflow-hidden"
            style={{
              width: 340,
              maxHeight: 520,
              boxShadow: "0 20px 60px rgba(0,0,0,0.8), 0 0 30px rgba(214,179,106,0.1)",
            }}
          >
            {/* Header */}
            <div className="flex items-center justify-between px-5 pt-4 pb-3 border-b border-white/8 flex-shrink-0">
              <div className="flex items-center gap-2.5">
                <div className="relative">
                  <div className="w-7 h-7 rounded-full bg-primary/20 flex items-center justify-center">
                    <Mic size={13} className="text-gold" />
                  </div>
                  {speaking && (
                    <span className="absolute -top-0.5 -right-0.5 w-2.5 h-2.5 rounded-full bg-green-400 border border-black animate-pulse" />
                  )}
                </div>
                <div>
                  <p className="text-sm font-medium text-foreground leading-none">AURA</p>
                  <p className="text-xs text-muted-foreground mt-0.5">
                    {recording ? "Listening…" : speaking ? "Speaking…" : loading ? "Thinking…" : "AI Assistant"}
                  </p>
                </div>
              </div>
              <button onClick={handleClose} className="w-7 h-7 rounded-lg bg-white/5 hover:bg-white/10 flex items-center justify-center transition-colors">
                <X size={13} className="text-muted-foreground" />
              </button>
            </div>

            {/* Waveform */}
            <div className="flex items-center justify-center gap-0.5 h-8 px-5 py-1 flex-shrink-0">
              {BARS.map((h, i) => (
                <motion.div
                  key={i}
                  className="w-1 rounded-full"
                  style={{ backgroundColor: recording ? "#ef4444" : "rgba(214,179,106,0.6)", minHeight: "3px" }}
                  animate={recording || loading || speaking ? {
                    height: [`${h}px`, `${h * 2.2}px`, `${h}px`],
                  } : { height: "3px" }}
                  transition={{
                    duration: 0.55,
                    delay: i * 0.04,
                    repeat: Infinity,
                    ease: "easeInOut",
                  }}
                />
              ))}
            </div>

            {/* Chat messages */}
            <div className="flex-1 overflow-y-auto px-4 py-2 space-y-2" style={{ minHeight: 0 }}>
              {messages.map((msg, i) => (
                <motion.div
                  key={i}
                  initial={{ opacity: 0, y: 6 }}
                  animate={{ opacity: 1, y: 0 }}
                  className={`flex ${msg.role === "user" ? "justify-end" : "justify-start"}`}
                >
                  <div
                    className={`max-w-[80%] px-3 py-2 rounded-xl text-xs leading-relaxed ${
                      msg.role === "user"
                        ? "bg-primary/20 text-foreground border border-primary/20"
                        : "bg-white/5 text-muted-foreground border border-white/8"
                    }`}
                  >
                    {msg.text}
                  </div>
                </motion.div>
              ))}

              {loading && (
                <div className="flex justify-start">
                  <div className="px-3 py-2 rounded-xl bg-white/5 border border-white/8 flex items-center gap-1.5">
                    <Loader2 size={11} className="text-primary animate-spin" />
                    <span className="text-xs text-muted-foreground">Thinking…</span>
                  </div>
                </div>
              )}
              <div ref={messagesEndRef} />
            </div>

            {/* Pending meal card */}
            <AnimatePresence>
              {pendingMeal && (
                <motion.div
                  initial={{ opacity: 0, height: 0 }}
                  animate={{ opacity: 1, height: "auto" }}
                  exit={{ opacity: 0, height: 0 }}
                  className="mx-4 mb-2 p-3 rounded-xl bg-primary/8 border border-primary/20 flex-shrink-0"
                >
                  <div className="flex items-center justify-between mb-2">
                    <p className="text-xs font-medium text-foreground">{pendingMeal.name}</p>
                    <span className="text-xs text-gold">{pendingMeal.calories} kcal</span>
                  </div>
                  <div className="flex gap-2 text-xs text-muted-foreground mb-2">
                    <span>{pendingMeal.protein}g protein</span>
                    <span>·</span>
                    <span>{pendingMeal.fat}g fat</span>
                    <span>·</span>
                    <span>{pendingMeal.carbs}g carbs</span>
                  </div>
                  <div className="flex gap-1.5">
                    {PERIODS.map(p => (
                      <button
                        key={p}
                        onClick={() => setSelectedPeriod(p)}
                        className={`flex-1 py-1 rounded-lg text-xs capitalize transition-all ${
                          selectedPeriod === p
                            ? "bg-primary text-black font-medium"
                            : "bg-white/5 text-muted-foreground hover:bg-white/10"
                        }`}
                      >
                        {p}
                      </button>
                    ))}
                  </div>
                  <div className="flex gap-2 mt-2">
                    <button
                      onClick={handleAddMeal}
                      disabled={createMeal.isPending}
                      className="flex-1 py-1.5 rounded-lg bg-primary text-black text-xs font-semibold disabled:opacity-50 hover:opacity-90 transition-all"
                    >
                      {createMeal.isPending ? "Adding…" : "Add to log"}
                    </button>
                    <button
                      onClick={() => setPendingMeal(null)}
                      className="px-3 py-1.5 rounded-lg bg-white/5 text-muted-foreground text-xs hover:bg-white/10 transition-all"
                    >
                      Dismiss
                    </button>
                  </div>
                </motion.div>
              )}
            </AnimatePresence>

            {/* Input row */}
            <div className="px-4 pb-4 pt-2 flex gap-2 flex-shrink-0 border-t border-white/8">
              <input
                data-testid="voice-command-input"
                value={text}
                onChange={e => setText(e.target.value)}
                onKeyDown={e => e.key === "Enter" && handleSendText()}
                placeholder="Type a command…"
                disabled={loading || recording}
                className="flex-1 bg-white/5 border border-white/10 rounded-xl px-3 py-2 text-xs text-foreground placeholder:text-muted-foreground outline-none focus:border-primary/50 transition-all disabled:opacity-50"
              />

              {/* Mic button */}
              <motion.button
                data-testid="voice-mic-btn"
                onClick={recording ? stopRecording : startRecording}
                disabled={loading}
                className={`w-9 h-9 rounded-xl flex items-center justify-center flex-shrink-0 transition-all ${
                  recording
                    ? "bg-red-500 hover:bg-red-600"
                    : "bg-white/10 hover:bg-white/20"
                }`}
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                title={recording ? "Stop recording" : "Start recording"}
              >
                {recording ? <MicOff size={14} className="text-white" /> : <Mic size={14} className="text-muted-foreground" />}
              </motion.button>

              {/* Send text button */}
              <motion.button
                data-testid="voice-send-btn"
                onClick={handleSendText}
                disabled={!text.trim() || loading || recording}
                className="w-9 h-9 rounded-xl bg-primary flex items-center justify-center flex-shrink-0 disabled:opacity-40 transition-all"
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
              >
                {loading ? <Loader2 size={13} className="text-black animate-spin" /> : <Send size={13} className="text-black" />}
              </motion.button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}
