import { pgTable, serial, text, boolean, integer, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const usersTable = pgTable("users", {
  id: serial("id").primaryKey(),
  email: text("email").notNull().unique(),
  passwordHash: text("password_hash").notNull(),
  name: text("name").notNull(),
  onboardingComplete: boolean("onboarding_complete").notNull().default(false),
  ageGroup: text("age_group"),
  diet: text("diet"),
  goal: text("goal"),
  goalDeadline: text("goal_deadline"),
  calorieTarget: integer("calorie_target"),
  proteinTarget: integer("protein_target"),
  fatTarget: integer("fat_target"),
  avatarUrl: text("avatar_url"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const insertUserSchema = createInsertSchema(usersTable).omit({ id: true, createdAt: true });
export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof usersTable.$inferSelect;
